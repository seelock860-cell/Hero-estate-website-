import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import {
  initDB,
  getProperties,
  getPropertyById,
  addProperty,
  updateProperty,
  deleteProperty,
  getEnquiries,
  addEnquiry,
  updateEnquiryStatus,
  deleteEnquiry,
  verifyAdminCredentials,
  changeAdminPassword,
  createSession,
  verifySession,
  getDashboardStats,
  getSupabaseConfig,
  saveSupabaseConfig,
  testSupabaseConnection,
  cleanSupabaseCredentials,
  pushPropertiesToSupabase,
  pullPropertiesFromSupabase,
  getPropertiesAsync,
  syncPropertyToSupabase,
  deletePropertyFromSupabase,
  syncEnquiryToSupabase,
  updateEnquiryStatusInSupabase,
  deleteEnquiryFromSupabase
} from './server/db.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

// Initialize database storage
initDB();

// Uploads directory for user uploaded property files and images
const UPLOADS_DIR = path.resolve(__dirname, 'server', 'data', 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}
app.use('/uploads', express.static(UPLOADS_DIR));

// Support larger payload sizes for user file uploads
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Auth middleware for /api/admin/*
function requireAuth(req: express.Request, res: express.Response, next: express.NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Unauthorized: Missing or invalid token' });
    return;
  }
  const token = authHeader.split(' ')[1];
  if (!verifySession(token)) {
    res.status(401).json({ error: 'Unauthorized: Session expired or invalid' });
    return;
  }
  next();
}

// ================= API ROUTES =================

// Public properties listing with full search & filtering
app.get('/api/properties', async (req, res) => {
  try {
    let properties = await getPropertiesAsync(true);
    const { state, city, property_type, listing_type, min_price, max_price, query } = req.query;

    if (state && typeof state === 'string' && state !== 'all') {
      properties = properties.filter(p => p.state.toLowerCase() === state.toLowerCase());
    }

    if (city && typeof city === 'string' && city !== 'all') {
      properties = properties.filter(p => p.city.toLowerCase().includes(city.toLowerCase()));
    }

    if (property_type && typeof property_type === 'string' && property_type !== 'all') {
      properties = properties.filter(p => p.property_type.toLowerCase() === property_type.toLowerCase());
    }

    if (listing_type && typeof listing_type === 'string' && listing_type !== 'all') {
      properties = properties.filter(p => p.listing_type.toLowerCase() === listing_type.toLowerCase());
    }

    if (min_price) {
      const min = Number(min_price);
      if (!isNaN(min)) {
        properties = properties.filter(p => p.price >= min);
      }
    }

    if (max_price) {
      const max = Number(max_price);
      if (!isNaN(max)) {
        properties = properties.filter(p => p.price <= max);
      }
    }

    if (query && typeof query === 'string' && query.trim() !== '') {
      const q = query.toLowerCase().trim();
      properties = properties.filter(p => 
        p.title.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.city.toLowerCase().includes(q) ||
        p.state.toLowerCase().includes(q) ||
        p.address.toLowerCase().includes(q)
      );
    }

    res.json({ success: true, count: properties.length, properties });
  } catch (error) {
    console.error('Error fetching properties:', error);
    res.status(500).json({ error: 'Failed to fetch properties' });
  }
});

// Single property details
app.get('/api/properties/:id', (req, res) => {
  const property = getPropertyById(req.params.id);
  if (!property) {
    res.status(404).json({ error: 'Property not found' });
    return;
  }
  res.json({ success: true, property });
});

// Customer enquiry submission
app.post('/api/enquiries', (req, res) => {
  try {
    const { customer_name, phone_number, email, message, property_id, property_title } = req.body;
    
    if (!customer_name || !phone_number || !message) {
      res.status(400).json({ error: 'Name, phone number, and message are required' });
      return;
    }

    const newEnquiry = addEnquiry({
      customer_name: customer_name.trim(),
      phone_number: phone_number.trim(),
      email: (email || '').trim(),
      message: message.trim(),
      property_id,
      property_title
    });

    // Background sync to Supabase if connected
    syncEnquiryToSupabase(newEnquiry);

    res.status(201).json({ success: true, enquiry: newEnquiry });
  } catch (error) {
    console.error('Error submitting enquiry:', error);
    res.status(500).json({ error: 'Failed to submit enquiry' });
  }
});

// Admin Auth
app.post('/api/auth/login', (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      res.status(400).json({ error: 'Username and password are required' });
      return;
    }

    const auth = verifyAdminCredentials(username.trim(), password);
    if (!auth.success) {
      res.status(401).json({ error: 'Invalid username or password' });
      return;
    }

    const token = createSession(username.trim());
    res.json({
      success: true,
      token,
      username: username.trim(),
      role: 'superadmin',
      is_initial_password: !!auth.is_initial_password
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Internal server error during login' });
  }
});

app.get('/api/auth/verify', (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'No token provided' });
    return;
  }
  const token = authHeader.split(' ')[1];
  if (!verifySession(token)) {
    res.status(401).json({ error: 'Session expired' });
    return;
  }
  res.json({ success: true, valid: true });
});

app.post('/api/auth/change-password', requireAuth, (req, res) => {
  try {
    const { new_password } = req.body;
    if (!new_password || new_password.length < 6) {
      res.status(400).json({ error: 'Password must be at least 6 characters long' });
      return;
    }

    const changed = changeAdminPassword(new_password);
    if (changed) {
      res.json({ success: true, message: 'Password updated successfully' });
    } else {
      res.status(500).json({ error: 'Failed to update password' });
    }
  } catch (error) {
    console.error('Password change error:', error);
    res.status(500).json({ error: 'Failed to update password' });
  }
});

// Admin Dashboard stats
app.get('/api/admin/stats', requireAuth, (_req, res) => {
  const stats = getDashboardStats();
  res.json({ success: true, stats });
});

// Admin Property CRUD
app.get('/api/admin/properties', requireAuth, (_req, res) => {
  const properties = getProperties(false);
  res.json({ success: true, properties });
});

// Admin File Upload (images, brochures, documents)
app.post('/api/admin/upload', requireAuth, (req, res) => {
  try {
    const { name, data } = req.body;
    if (!name || !data) {
      res.status(400).json({ error: 'Name and file data are required' });
      return;
    }

    // Match base64 data URL
    const matches = data.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
    if (!matches || matches.length !== 3) {
      // Return provided string as url fallback
      res.json({ success: true, url: data, name });
      return;
    }

    const ext = path.extname(name) || '.jpg';
    const cleanBaseName = path.basename(name, ext).replace(/[^a-zA-Z0-9_-]/g, '_');
    const filename = `${cleanBaseName}_${Date.now()}${ext}`;
    const filePath = path.join(UPLOADS_DIR, filename);
    const buffer = Buffer.from(matches[2], 'base64');
    fs.writeFileSync(filePath, buffer);

    res.json({ success: true, url: `/uploads/${filename}`, filename });
  } catch (error) {
    console.error('File upload error:', error);
    // Return data URL as reliable fallback
    res.json({ success: true, url: req.body?.data || '', name: req.body?.name });
  }
});

app.post('/api/admin/properties', requireAuth, (req, res) => {
  try {
    const propData = req.body;
    if (!propData.title || !propData.price || !propData.state || !propData.city) {
      res.status(400).json({ error: 'Title, price, state, and city are required' });
      return;
    }
    const created = addProperty(propData);
    syncPropertyToSupabase(created);
    res.status(201).json({ success: true, property: created });
  } catch (error) {
    console.error('Add property error:', error);
    res.status(500).json({ error: 'Failed to add property' });
  }
});

app.put('/api/admin/properties/:id', requireAuth, (req, res) => {
  try {
    const updated = updateProperty(req.params.id, req.body);
    if (!updated) {
      res.status(404).json({ error: 'Property not found' });
      return;
    }
    syncPropertyToSupabase(updated);
    res.json({ success: true, property: updated });
  } catch (error) {
    console.error('Update property error:', error);
    res.status(500).json({ error: 'Failed to update property' });
  }
});

app.delete('/api/admin/properties/:id', requireAuth, (req, res) => {
  try {
    const deleted = deleteProperty(req.params.id);
    if (!deleted) {
      res.status(404).json({ error: 'Property not found' });
      return;
    }
    deletePropertyFromSupabase(req.params.id);
    res.json({ success: true, message: 'Property deleted' });
  } catch (error) {
    console.error('Delete property error:', error);
    res.status(500).json({ error: 'Failed to delete property' });
  }
});

// Admin Enquiries CRUD
app.get('/api/admin/enquiries', requireAuth, (_req, res) => {
  const enquiries = getEnquiries();
  res.json({ success: true, enquiries });
});

app.patch('/api/admin/enquiries/:id', requireAuth, (req, res) => {
  try {
    const { status } = req.body;
    if (status !== 'pending' && status !== 'resolved') {
      res.status(400).json({ error: 'Invalid status' });
      return;
    }
    const updated = updateEnquiryStatus(req.params.id, status);
    if (!updated) {
      res.status(404).json({ error: 'Enquiry not found' });
      return;
    }
    updateEnquiryStatusInSupabase(req.params.id, status);
    res.json({ success: true, enquiry: updated });
  } catch (error) {
    console.error('Update enquiry error:', error);
    res.status(500).json({ error: 'Failed to update enquiry' });
  }
});

app.delete('/api/admin/enquiries/:id', requireAuth, (req, res) => {
  try {
    const deleted = deleteEnquiry(req.params.id);
    if (!deleted) {
      res.status(404).json({ error: 'Enquiry not found' });
      return;
    }
    deleteEnquiryFromSupabase(req.params.id);
    res.json({ success: true, message: 'Enquiry deleted' });
  } catch (error) {
    console.error('Delete enquiry error:', error);
    res.status(500).json({ error: 'Failed to delete enquiry' });
  }
});

// Admin Supabase Settings
app.get('/api/admin/supabase-config', requireAuth, (_req, res) => {
  const config = getSupabaseConfig();
  res.json({ success: true, config });
});

app.post('/api/admin/supabase-config', requireAuth, async (req, res) => {
  try {
    const { project_url, publishable_key } = req.body;
    const testResult = await testSupabaseConnection(project_url, publishable_key);
    
    const config = {
      project_url: testResult.cleanedUrl || (project_url || '').trim(),
      publishable_key: testResult.cleanedKey || (publishable_key || '').trim(),
      status: testResult.success ? ('connected' as const) : ('error' as const),
      last_tested: new Date().toISOString(),
      error_message: testResult.success ? undefined : testResult.message
    };
    saveSupabaseConfig(config);
    res.json({ success: true, config, testResult });
  } catch (error) {
    console.error('Save config error:', error);
    res.status(500).json({ error: 'Failed to save configuration' });
  }
});

app.post('/api/admin/supabase-test', requireAuth, async (req, res) => {
  try {
    const { project_url, publishable_key } = req.body;
    const result = await testSupabaseConnection(project_url, publishable_key);
    res.json(result);
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : String(error);
    res.status(500).json({ success: false, message: msg });
  }
});

// Push local properties to Supabase
app.post('/api/admin/supabase-push', requireAuth, async (_req, res) => {
  try {
    const result = await pushPropertiesToSupabase();
    res.json(result);
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : String(error);
    res.status(500).json({ success: false, message: msg });
  }
});

// Pull properties from Supabase into local cache
app.post('/api/admin/supabase-pull', requireAuth, async (_req, res) => {
  try {
    const result = await pullPropertiesFromSupabase();
    res.json(result);
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : String(error);
    res.status(500).json({ success: false, message: msg });
  }
});

// ================= FRONTEND / VITE INTEGRATION =================
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`HERO REAL ESTATE server running on port ${PORT} in ${isProduction ? 'production' : 'development'} mode`);
  });
}

startServer().catch(err => {
  console.error('Fatal server startup error:', err);
  process.exit(1);
});
