import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createClient } from '@supabase/supabase-js';
import type { Property, CustomerEnquiry, SupabaseConfig, DashboardStats } from '../src/types.ts';

const DATA_DIR = path.resolve(process.cwd(), 'server', 'data');
const PROPERTIES_FILE = path.join(DATA_DIR, 'properties.json');
const ENQUIRIES_FILE = path.join(DATA_DIR, 'enquiries.json');
const ADMIN_FILE = path.join(DATA_DIR, 'admin.json');
const CONFIG_FILE = path.join(DATA_DIR, 'supabase_config.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

function hashPassword(password: string, salt: string): string {
  return crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
}

// Initial properties based on user specifications
const INITIAL_PROPERTIES: Property[] = [
  {
    id: 'prop-1',
    title: '4 Bedroom Contemporary Duplex with BQ',
    description: 'An exquisitely built and masterfully finished 4-bedroom detached duplex located in a secure gated estate in Lekki Phase 1. Features high ceilings, fully fitted modern Italian kitchen, expansive private parking for 4 vehicles, and a detached boys quarters.',
    property_type: 'duplex',
    listing_type: 'rent',
    price: 2500000,
    price_period: 'year',
    state: 'Lagos',
    city: 'Lekki',
    address: 'Admiralty Way, Lekki Phase 1, Lagos State',
    bedrooms: 4,
    bathrooms: 4,
    parking_spaces: 4,
    image_urls: [
      '/src/assets/images/property_lekki_duplex_1792834142472.jpg',
      '/src/assets/images/hero_luxury_mansion_1792834141681.jpg',
      '/src/assets/images/property_vi_apartment_1792834142916.jpg'
    ],
    availability_status: 'available',
    published: true,
    featured: true,
    amenities: ['24/7 Electricity', 'Armed Security', 'CCTV Surveillance', 'Water Treatment Plant', 'Fitted Kitchen', 'Boys Quarters'],
    created_at: new Date('2026-03-15').toISOString(),
    updated_at: new Date('2026-03-15').toISOString()
  },
  {
    id: 'prop-2',
    title: '2 Bedroom Waterfront Luxury Apartment',
    description: 'Breathtaking 2-bedroom luxury serviced apartment facing the Lagos Marina and Victoria Island skyline. Comes fully furnished with designer Italian pieces, marble flooring, private gym access, concierge service, and panoramic sunset views.',
    property_type: 'apartment',
    listing_type: 'rent',
    price: 1200000,
    price_period: 'year',
    state: 'Lagos',
    city: 'Victoria Island',
    address: 'Ozumba Mbadiwe Avenue, Victoria Island, Lagos',
    bedrooms: 2,
    bathrooms: 2,
    parking_spaces: 2,
    image_urls: [
      '/src/assets/images/property_vi_apartment_1792834142916.jpg',
      '/src/assets/images/hero_luxury_mansion_1792834141681.jpg'
    ],
    availability_status: 'available',
    published: true,
    featured: true,
    amenities: ['Concierge Service', 'Swimming Pool', 'Ocean View', '24/7 Power', 'Elevator', 'Fitness Gym'],
    created_at: new Date('2026-03-20').toISOString(),
    updated_at: new Date('2026-03-20').toISOString()
  },
  {
    id: 'prop-3',
    title: '3 Bedroom Contemporary Stone Bungalow',
    description: 'Charming and private 3-bedroom detached bungalow set amidst lush manicured green lawns in prestigious Maitama, Abuja. Features natural stone cladding, automated access gate, solar inverter backup, and a serene ambiance.',
    property_type: 'bungalow',
    listing_type: 'rent',
    price: 850000,
    price_period: 'year',
    state: 'Abuja FCT',
    city: 'Maitama',
    address: 'Gana Street, Maitama District, Abuja',
    bedrooms: 3,
    bathrooms: 3,
    parking_spaces: 3,
    image_urls: [
      '/src/assets/images/property_abuja_bungalow_1792834142908.jpg',
      '/src/assets/images/hero_luxury_mansion_1792834141681.jpg'
    ],
    availability_status: 'available',
    published: true,
    featured: true,
    amenities: ['Solar Power Backup', 'Landscaped Garden', 'Automated Gate', 'Borehole with Filtration', 'Perimeter Electric Fence'],
    created_at: new Date('2026-03-10').toISOString(),
    updated_at: new Date('2026-03-10').toISOString()
  },
  {
    id: 'prop-4',
    title: '3 Bedroom Luxury Terrace Duplex',
    description: 'Immaculate 3-bedroom luxury terrace duplex nestled in an upscale private residential court along Peter Odili Road in Port Harcourt. Fitted with modern chandeliers, walk-in closets, smart home controls, and dedicated security post.',
    property_type: 'terrace',
    listing_type: 'rent',
    price: 1500000,
    price_period: 'year',
    state: 'Rivers',
    city: 'Port Harcourt',
    address: 'Peter Odili Road, Trans-Amadi, Port Harcourt',
    bedrooms: 3,
    bathrooms: 3,
    parking_spaces: 2,
    image_urls: [
      '/src/assets/images/property_lekki_duplex_1792834142472.jpg',
      '/src/assets/images/property_vi_apartment_1792834142916.jpg'
    ],
    availability_status: 'available',
    published: true,
    featured: true,
    amenities: ['Uniformed Security', 'Smart Lighting', 'Pre-installed Air Conditioning', 'Ample Parking', 'Children Play Area'],
    created_at: new Date('2026-03-18').toISOString(),
    updated_at: new Date('2026-03-18').toISOString()
  },
  {
    id: 'prop-5',
    title: '5 Bedroom Waterfront Royal Palace Mansion',
    description: 'An architectural tour-de-force on the ultra-exclusive Banana Island waterfront. Features a heated infinity pool overlooking the lagoon, private boat jetty, private cinema room, elevator, wine cellar, and smart building management system.',
    property_type: 'mansion',
    listing_type: 'sale',
    price: 450000000,
    price_period: 'outright',
    state: 'Lagos',
    city: 'Ikoyi',
    address: 'Zone A, Banana Island, Ikoyi, Lagos',
    bedrooms: 5,
    bathrooms: 6,
    parking_spaces: 6,
    image_urls: [
      '/src/assets/images/hero_luxury_mansion_1792834141681.jpg',
      '/src/assets/images/property_vi_apartment_1792834142916.jpg',
      '/src/assets/images/property_lekki_duplex_1792834142472.jpg'
    ],
    availability_status: 'available',
    published: true,
    featured: true,
    amenities: ['Private Boat Jetty', 'Infinity Pool', 'Lagoon Frontage', 'Private Cinema', 'Elevator', '2 BQs', 'Full Home Automation'],
    created_at: new Date('2026-03-01').toISOString(),
    updated_at: new Date('2026-03-01').toISOString()
  },
  {
    id: 'prop-6',
    title: '4 Bedroom Luxury Serviced Penthouse',
    description: 'Superb high-rise penthouse situated in Eko Atlantic City with commanding views of the Atlantic Ocean and coastal breeze. Highlights include double-height floor-to-ceiling glass, rooftop terrace, and five-star concierge services.',
    property_type: 'penthouse',
    listing_type: 'sale',
    price: 220000000,
    price_period: 'outright',
    state: 'Lagos',
    city: 'Victoria Island',
    address: 'Eko Atlantic City, Victoria Island, Lagos',
    bedrooms: 4,
    bathrooms: 4,
    parking_spaces: 3,
    image_urls: [
      '/src/assets/images/property_vi_apartment_1792834142916.jpg',
      '/src/assets/images/hero_luxury_mansion_1792834141681.jpg'
    ],
    availability_status: 'available',
    published: true,
    featured: false,
    amenities: ['Atlantic Ocean View', 'Rooftop Lounge', 'Helipad Access', '24/7 Power', 'Olympic Pool', 'Valet Parking'],
    created_at: new Date('2026-03-22').toISOString(),
    updated_at: new Date('2026-03-22').toISOString()
  }
];

const INITIAL_ENQUIRIES: CustomerEnquiry[] = [
  {
    id: 'enq-1',
    customer_name: 'Dr. Babatunde Adeleke',
    phone_number: '+234 803 555 0192',
    email: 'b.adeleke@lagoshealth.org',
    message: 'Good day HERO REAL ESTATE, I would like to schedule an inspection for the 4 Bedroom Duplex in Lekki Phase 1 this weekend.',
    property_id: 'prop-1',
    property_title: '4 Bedroom Contemporary Duplex with BQ',
    status: 'pending',
    created_at: new Date('2026-03-22T10:14:00Z').toISOString()
  },
  {
    id: 'enq-2',
    customer_name: 'Mrs. Chidinma Okafor',
    phone_number: '+234 812 443 8901',
    email: 'chidinma.okafor@primeconsult.ng',
    message: 'Inquiring about availability and service charge details for the 2 Bedroom Waterfront Apartment in Victoria Island.',
    property_id: 'prop-2',
    property_title: '2 Bedroom Waterfront Luxury Apartment',
    status: 'resolved',
    created_at: new Date('2026-03-21T14:30:00Z').toISOString()
  }
];

// Initialize Files
export function initDB() {
  if (!fs.existsSync(PROPERTIES_FILE)) {
    fs.writeFileSync(PROPERTIES_FILE, JSON.stringify(INITIAL_PROPERTIES, null, 2));
  }
  if (!fs.existsSync(ENQUIRIES_FILE)) {
    fs.writeFileSync(ENQUIRIES_FILE, JSON.stringify(INITIAL_ENQUIRIES, null, 2));
  }
  if (!fs.existsSync(ADMIN_FILE)) {
    const salt = crypto.randomBytes(16).toString('hex');
    const password_hash = hashPassword('hero123', salt);
    const adminData = {
      username: 'hero',
      role: 'superadmin',
      salt,
      password_hash,
      is_initial_password: true,
      created_at: new Date().toISOString()
    };
    fs.writeFileSync(ADMIN_FILE, JSON.stringify(adminData, null, 2));
  }
  if (!fs.existsSync(CONFIG_FILE)) {
    const supabaseConfig: SupabaseConfig = {
      project_url: process.env.VITE_SUPABASE_URL || '',
      publishable_key: process.env.VITE_SUPABASE_ANON_KEY || '',
      status: (process.env.VITE_SUPABASE_URL && process.env.VITE_SUPABASE_ANON_KEY) ? 'connected' : 'unconfigured'
    };
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(supabaseConfig, null, 2));
  }
}

// Active session tokens
const activeSessions = new Map<string, { username: string; expiresAt: number }>();

export function createSession(username: string): string {
  const token = crypto.randomBytes(32).toString('hex');
  const expiresAt = Date.now() + 24 * 60 * 60 * 1000; // 24 hours
  activeSessions.set(token, { username, expiresAt });
  return token;
}

export function verifySession(token: string): boolean {
  if (!token) return false;
  const session = activeSessions.get(token);
  if (!session) return false;
  if (Date.now() > session.expiresAt) {
    activeSessions.delete(token);
    return false;
  }
  return true;
}

// Properties methods
export function getProperties(filterPublished = true): Property[] {
  try {
    if (!fs.existsSync(PROPERTIES_FILE)) initDB();
    const data = fs.readFileSync(PROPERTIES_FILE, 'utf-8');
    const properties: Property[] = JSON.parse(data);
    if (filterPublished) {
      return properties.filter(p => p.published);
    }
    return properties;
  } catch (err) {
    console.error('Error reading properties:', err);
    return INITIAL_PROPERTIES;
  }
}

export function getPropertyById(id: string): Property | undefined {
  const properties = getProperties(false);
  return properties.find(p => p.id === id);
}

export function saveProperties(properties: Property[]) {
  fs.writeFileSync(PROPERTIES_FILE, JSON.stringify(properties, null, 2));
}

export function addProperty(propertyData: Omit<Property, 'id' | 'created_at' | 'updated_at'>): Property {
  const properties = getProperties(false);
  const newProperty: Property = {
    ...propertyData,
    id: `prop-${Date.now()}`,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  };
  properties.unshift(newProperty);
  saveProperties(properties);
  return newProperty;
}

export function updateProperty(id: string, updates: Partial<Property>): Property | null {
  const properties = getProperties(false);
  const index = properties.findIndex(p => p.id === id);
  if (index === -1) return null;

  properties[index] = {
    ...properties[index],
    ...updates,
    id, // protect id
    updated_at: new Date().toISOString()
  };
  saveProperties(properties);
  return properties[index];
}

export function deleteProperty(id: string): boolean {
  const properties = getProperties(false);
  const filtered = properties.filter(p => p.id !== id);
  if (filtered.length === properties.length) return false;
  saveProperties(filtered);
  return true;
}

// Enquiries methods
export function getEnquiries(): CustomerEnquiry[] {
  try {
    if (!fs.existsSync(ENQUIRIES_FILE)) initDB();
    const data = fs.readFileSync(ENQUIRIES_FILE, 'utf-8');
    return JSON.parse(data);
  } catch {
    return [];
  }
}

export function addEnquiry(enquiry: Omit<CustomerEnquiry, 'id' | 'status' | 'created_at'>): CustomerEnquiry {
  const enquiries = getEnquiries();
  const newEnquiry: CustomerEnquiry = {
    ...enquiry,
    id: `enq-${Date.now()}`,
    status: 'pending',
    created_at: new Date().toISOString()
  };
  enquiries.unshift(newEnquiry);
  fs.writeFileSync(ENQUIRIES_FILE, JSON.stringify(enquiries, null, 2));
  return newEnquiry;
}

export function updateEnquiryStatus(id: string, status: 'pending' | 'resolved'): CustomerEnquiry | null {
  const enquiries = getEnquiries();
  const item = enquiries.find(e => e.id === id);
  if (!item) return null;
  item.status = status;
  fs.writeFileSync(ENQUIRIES_FILE, JSON.stringify(enquiries, null, 2));
  return item;
}

export function deleteEnquiry(id: string): boolean {
  const enquiries = getEnquiries();
  const filtered = enquiries.filter(e => e.id !== id);
  if (filtered.length === enquiries.length) return false;
  fs.writeFileSync(ENQUIRIES_FILE, JSON.stringify(filtered, null, 2));
  return true;
}

// Admin Authentication
export function verifyAdminCredentials(username: string, password: string): { success: boolean; is_initial_password?: boolean } {
  try {
    if (!fs.existsSync(ADMIN_FILE)) initDB();
    const adminData = JSON.parse(fs.readFileSync(ADMIN_FILE, 'utf-8'));
    if (adminData.username !== username) {
      return { success: false };
    }
    const hash = hashPassword(password, adminData.salt);
    if (hash === adminData.password_hash) {
      return { success: true, is_initial_password: adminData.is_initial_password };
    }
    return { success: false };
  } catch {
    return { success: false };
  }
}

export function changeAdminPassword(newPassword: string): boolean {
  try {
    if (!fs.existsSync(ADMIN_FILE)) initDB();
    const adminData = JSON.parse(fs.readFileSync(ADMIN_FILE, 'utf-8'));
    const newSalt = crypto.randomBytes(16).toString('hex');
    const newHash = hashPassword(newPassword, newSalt);
    adminData.salt = newSalt;
    adminData.password_hash = newHash;
    adminData.is_initial_password = false;
    adminData.updated_at = new Date().toISOString();
    fs.writeFileSync(ADMIN_FILE, JSON.stringify(adminData, null, 2));
    return true;
  } catch {
    return false;
  }
}

export function getAdminProfile(): { username: string; role: string; is_initial_password: boolean } {
  if (!fs.existsSync(ADMIN_FILE)) initDB();
  const data = JSON.parse(fs.readFileSync(ADMIN_FILE, 'utf-8'));
  return {
    username: data.username,
    role: data.role,
    is_initial_password: !!data.is_initial_password
  };
}

// Clean & normalize Supabase credentials (handles Postgres URLs, quotes, trailing slashes, missing https)
export function cleanSupabaseCredentials(rawUrl: string, rawKey: string): {
  url: string;
  key: string;
  warnings?: string[];
  error?: string;
} {
  let url = (rawUrl || '').trim().replace(/^["']|["']$/g, '');
  let key = (rawKey || '').trim().replace(/^["']|["']$/g, '');
  const warnings: string[] = [];

  if (!url || !key) {
    return { url: '', key: '', error: 'Both Supabase Project URL and Public API Key are required.' };
  }

  // Strip 'Bearer ' if user accidentally copied it with Bearer prefix
  key = key.replace(/^Bearer\s+/i, '').trim();

  // Remove accidental spaces inside the key
  key = key.replace(/\s+/g, '');

  // Detect Postgres URI pasted instead of Project URL
  if (url.startsWith('postgres://') || url.startsWith('postgresql://') || url.includes(':5432') || url.includes(':6543')) {
    const match = url.match(/postgres\.([a-z0-9_-]+):/) || url.match(/@([a-z0-9_-]+)\.supabase\.co/);
    if (match && match[1]) {
      url = `https://${match[1]}.supabase.co`;
      warnings.push(`We automatically converted your Postgres database URI into your Project URL (${url}).`);
    } else {
      return {
        url,
        key,
        error: 'You pasted a Postgres connection string instead of the Supabase Project URL. Please use: https://[your-project-id].supabase.co (found in Supabase under Project Settings > API).'
      };
    }
  }

  // If user only pasted the project ID e.g. "qdrjabc123" without domain:
  if (/^[a-z0-9_-]{12,40}$/i.test(url)) {
    url = `https://${url}.supabase.co`;
    warnings.push(`We automatically expanded your project reference into ${url}`);
  }

  // Prepend https:// if protocol was omitted
  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    url = `https://${url}`;
  }

  // Strip trailing /rest/v1 or /rest or trailing slashes
  url = url.replace(/\/rest\/v1\/?$/i, '').replace(/\/rest\/?$/i, '').replace(/\/+$/, '');

  // Validate URL format
  try {
    const parsed = new URL(url);
    if (!parsed.hostname.includes('supabase') && !parsed.hostname.includes('localhost') && !parsed.hostname.includes('127.0.0.1')) {
      warnings.push('The URL does not contain "supabase.co". Ensure this is your correct Supabase host.');
    }
  } catch {
    return { url, key, error: 'Invalid URL format. Example: https://xyzcompany.supabase.co' };
  }

  return { url, key, warnings };
}

// Supabase Configuration
export function getSupabaseConfig(): SupabaseConfig {
  try {
    if (!fs.existsSync(CONFIG_FILE)) initDB();
    return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf-8'));
  } catch {
    return { project_url: '', publishable_key: '', status: 'unconfigured' };
  }
}

export function saveSupabaseConfig(config: SupabaseConfig) {
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
}

// Helper to get active Supabase client
export function getSupabaseClient() {
  const config = getSupabaseConfig();
  if (config.status === 'connected' && config.project_url && config.publishable_key) {
    try {
      return createClient(config.project_url, config.publishable_key, {
        auth: { persistSession: false, autoRefreshToken: false }
      });
    } catch {
      return null;
    }
  }
  return null;
}

export async function testSupabaseConnection(rawUrl: string, rawKey: string): Promise<{
  success: boolean;
  message: string;
  cleanedUrl?: string;
  cleanedKey?: string;
  tableExists?: boolean;
  tableCount?: number;
  warnings?: string[];
}> {
  const cleaned = cleanSupabaseCredentials(rawUrl, rawKey);
  if (cleaned.error) {
    return { success: false, message: cleaned.error };
  }

  const { url, key, warnings } = cleaned;

  try {
    const supabase = createClient(url, key, {
      auth: { persistSession: false, autoRefreshToken: false }
    });

    // Test query against Supabase
    const { data, error } = await supabase.from('properties').select('id').limit(1);

    if (error) {
      const errMsg = (error.message || '').toLowerCase();
      const errDetails = (error.details || '').toLowerCase();
      const errCode = error.code || '';

      // Check for authentication failure
      if (
        errCode === '401' ||
        errCode === 'PGRST301' ||
        errMsg.includes('jwt') ||
        errMsg.includes('api key') ||
        errMsg.includes('invalid api') ||
        errMsg.includes('unauthorized') ||
        errMsg.includes('token')
      ) {
        return {
          success: false,
          message: `Authentication failed: ${error.message}. Please verify that you copied the public "anon" key from Supabase Dashboard > Project Settings > API.`,
          warnings
        };
      }

      // Check if project is paused or offline
      if (errMsg.includes('paused') || errMsg.includes('project is paused')) {
        return {
          success: false,
          message: 'Your Supabase project appears to be paused. Please visit supabase.com, unpause your project, and try again.',
          warnings
        };
      }

      // If the table doesn't exist yet, this is a 100% verified connection to Supabase!
      if (
        errCode === '42P01' ||
        errCode === 'PGRST205' ||
        errCode === 'PGRST116' ||
        errMsg.includes('does not exist') ||
        errMsg.includes('not found') ||
        errMsg.includes('relation') ||
        errDetails.includes('does not exist')
      ) {
        return {
          success: true,
          message: 'Connected successfully to Supabase! Your credentials are valid and authorized. (Note: The "properties" table does not exist yet. Please copy the SQL script below, paste it into your Supabase SQL Editor and click RUN, then click "Push Properties to Supabase").',
          tableExists: false,
          tableCount: 0,
          cleanedUrl: url,
          cleanedKey: key,
          warnings
        };
      }

      // Any PostgREST code that reached the database successfully
      if (errCode.startsWith('PGRST') || errCode.startsWith('42')) {
        return {
          success: true,
          message: `Connected successfully to Supabase! (${error.message}). Run the SQL schema script below in Supabase SQL Editor to finish setting up tables.`,
          tableExists: false,
          tableCount: 0,
          cleanedUrl: url,
          cleanedKey: key,
          warnings
        };
      }

      return {
        success: false,
        message: `Supabase error: ${error.message} (${errCode || 'unknown'}). Please check your project settings.`,
        warnings
      };
    }

    return {
      success: true,
      message: 'Connected successfully to Supabase! Your Supabase database is active and tables are online.',
      tableExists: true,
      tableCount: data ? data.length : 0,
      cleanedUrl: url,
      cleanedKey: key,
      warnings
    };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    return { success: false, message: `Could not connect to ${url}: ${msg}. Please check your internet connection or Project URL.`, warnings };
  }
}

// Push local properties to Supabase
export async function pushPropertiesToSupabase(): Promise<{ success: boolean; pushed: number; message: string }> {
  const config = getSupabaseConfig();
  if (config.status !== 'connected' || !config.project_url || !config.publishable_key) {
    return { success: false, pushed: 0, message: 'Supabase is not connected. Save valid credentials first.' };
  }

  try {
    const supabase = createClient(config.project_url, config.publishable_key, { auth: { persistSession: false } });
    const localProps = getProperties(false);

    const { error } = await supabase.from('properties').upsert(localProps, { onConflict: 'id' });
    if (error) {
      return {
        success: false,
        pushed: 0,
        message: `Failed to push: ${error.message}. Make sure you ran the SQL schema in Supabase first.`
      };
    }

    return {
      success: true,
      pushed: localProps.length,
      message: `Successfully synchronized ${localProps.length} properties to your Supabase database!`
    };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    return { success: false, pushed: 0, message: `Push failed: ${msg}` };
  }
}

// Pull properties from Supabase into local cache
export async function pullPropertiesFromSupabase(): Promise<{ success: boolean; pulled: number; message: string }> {
  const config = getSupabaseConfig();
  if (config.status !== 'connected' || !config.project_url || !config.publishable_key) {
    return { success: false, pulled: 0, message: 'Supabase is not connected.' };
  }

  try {
    const supabase = createClient(config.project_url, config.publishable_key, { auth: { persistSession: false } });
    const { data, error } = await supabase.from('properties').select('*').order('created_at', { ascending: false });

    if (error) {
      return { success: false, pulled: 0, message: `Failed to pull from Supabase: ${error.message}` };
    }

    if (data && data.length > 0) {
      saveProperties(data as Property[]);
      return { success: true, pulled: data.length, message: `Successfully loaded ${data.length} properties from Supabase!` };
    }

    return { success: true, pulled: 0, message: 'Supabase currently has 0 properties stored. Click "Push Properties to Supabase" to seed them!' };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    return { success: false, pulled: 0, message: `Pull failed: ${msg}` };
  }
}

// Background sync helpers
export async function syncPropertyToSupabase(prop: Property) {
  const supabase = getSupabaseClient();
  if (!supabase) return;
  try {
    await supabase.from('properties').upsert(prop, { onConflict: 'id' });
  } catch (e) {
    console.warn('Background Supabase property sync error:', e);
  }
}

export async function deletePropertyFromSupabase(id: string) {
  const supabase = getSupabaseClient();
  if (!supabase) return;
  try {
    await supabase.from('properties').delete().eq('id', id);
  } catch (e) {
    console.warn('Background Supabase property delete error:', e);
  }
}

export async function syncEnquiryToSupabase(enquiry: CustomerEnquiry) {
  const supabase = getSupabaseClient();
  if (!supabase) return;
  try {
    await supabase.from('customer_enquiries').upsert(enquiry, { onConflict: 'id' });
  } catch (e) {
    console.warn('Background Supabase enquiry sync error:', e);
  }
}

export async function updateEnquiryStatusInSupabase(id: string, status: 'pending' | 'resolved') {
  const supabase = getSupabaseClient();
  if (!supabase) return;
  try {
    await supabase.from('customer_enquiries').update({ status }).eq('id', id);
  } catch (e) {
    console.warn('Background Supabase enquiry update error:', e);
  }
}

export async function deleteEnquiryFromSupabase(id: string) {
  const supabase = getSupabaseClient();
  if (!supabase) return;
  try {
    await supabase.from('customer_enquiries').delete().eq('id', id);
  } catch (e) {
  }
}

// Asynchronously fetch properties (preferring Supabase if available)
export async function getPropertiesAsync(filterPublished = true): Promise<Property[]> {
  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      let query = supabase.from('properties').select('*').order('created_at', { ascending: false });
      if (filterPublished) {
        query = query.eq('published', true);
      }
      const { data, error } = await query;
      if (!error && data && data.length > 0) {
        return data as Property[];
      }
    } catch (e) {
      console.warn('Supabase query error, falling back to local database:', e);
    }
  }
  return getProperties(filterPublished);
}

export function getDashboardStats(): DashboardStats {
  const properties = getProperties(false);
  const enquiries = getEnquiries();
  return {
    total_properties: properties.length,
    properties_for_rent: properties.filter(p => p.listing_type === 'rent').length,
    properties_for_sale: properties.filter(p => p.listing_type === 'sale').length,
    total_enquiries: enquiries.length,
    pending_enquiries: enquiries.filter(e => e.status === 'pending').length,
    recently_added: properties.slice(0, 5)
  };
}
