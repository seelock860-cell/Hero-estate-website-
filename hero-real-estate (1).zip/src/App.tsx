import { useState, useEffect } from 'react';
import { MessageSquare, ArrowUp } from 'lucide-react';
import Navbar from './components/Navbar.tsx';
import HeroSection from './components/HeroSection.tsx';
import PropertyListingsSection from './components/PropertyListingsSection.tsx';
import AboutAndTrustSection from './components/AboutAndTrustSection.tsx';
import ServicesSection from './components/ServicesSection.tsx';
import CTASection from './components/CTASection.tsx';
import ContactSection from './components/ContactSection.tsx';
import Footer from './components/Footer.tsx';
import PropertyDetailModal from './components/PropertyDetailModal.tsx';
import AdminLoginModal from './components/admin/AdminLoginModal.tsx';
import AdminDashboard from './components/admin/AdminDashboard.tsx';
import type { Property } from './types.ts';
import { getStoredToken, getStoredAdminUser, api } from './services/api.ts';
import { getWhatsAppUrl } from './utils/format.ts';

export default function App() {
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isAdminView, setIsAdminView] = useState(false);
  const [adminUser, setAdminUser] = useState<{ username: string; is_initial_password: boolean } | null>(null);
  const [showScrollTop, setShowScrollTop] = useState(false);

  // Search filters passed from HeroSection down to PropertyListingsSection
  const [heroSearchFilters, setHeroSearchFilters] = useState<{
    location?: string;
    property_type?: string;
    priceRange?: string;
    listing_type?: string;
  } | undefined>(undefined);

  // Check URL hash for #/admin or #admin (and verify session)
  useEffect(() => {
    const handleHash = () => {
      const hash = window.location.hash.toLowerCase();
      const pathname = window.location.pathname.toLowerCase();
      
      const isAdminRoute = hash === '#/admin' || hash === '#admin' || pathname === '/admin';
      
      if (isAdminRoute) {
        const token = getStoredToken();
        const storedUser = getStoredAdminUser();
        if (token && storedUser) {
          setAdminUser(storedUser);
          setIsAdminView(true);
        } else {
          setIsLoginModalOpen(true);
        }
      } else {
        setIsAdminView(false);
      }
    };

    handleHash();
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  // Track scroll position for scroll-to-top button
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 400) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLoginSuccess = (user: { username: string; is_initial_password: boolean }) => {
    setAdminUser(user);
    setIsAdminView(true);
    setIsLoginModalOpen(false);
    if (window.location.hash !== '#/admin') {
      window.location.hash = '#/admin';
    }
  };

  const handleCloseLoginModal = () => {
    setIsLoginModalOpen(false);
    const hash = window.location.hash.toLowerCase();
    if (hash === '#/admin' || hash === '#admin') {
      window.history.replaceState(null, '', window.location.pathname + window.location.search);
    }
  };

  const handleExitAdmin = () => {
    setIsAdminView(false);
    if (!getStoredToken()) {
      setAdminUser(null);
    }
    const hash = window.location.hash.toLowerCase();
    if (hash === '#/admin' || hash === '#admin') {
      window.history.replaceState(null, '', window.location.pathname + window.location.search);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const handleHeroSearch = (filters: {
    location?: string;
    property_type?: string;
    priceRange?: string;
    listing_type?: string;
  }) => {
    setHeroSearchFilters(filters);
  };

  // If currently in Admin Dashboard mode, render full admin interface
  if (isAdminView && adminUser) {
    return (
      <AdminDashboard
        adminUser={adminUser}
        onBackToSite={handleExitAdmin}
        onUpdateAdminUser={(updated) => setAdminUser(updated)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#080808] text-white flex flex-col selection:bg-[#F5BD45] selection:text-black">
      
      {/* Navigation - Admin dashboard button hidden; accessible via browser URL #/admin */}
      <Navbar
        onOpenSearch={() => scrollToSection('properties')}
      />

      {/* Hero Section */}
      <main className="flex-1">
        <HeroSection onSearch={handleHeroSearch} />

        {/* Property Listings (demonstration content editable by admin) */}
        <PropertyListingsSection
          onViewDetails={(prop) => setSelectedProperty(prop)}
          initialFilters={heroSearchFilters}
        />

        {/* About & Trust Section */}
        <AboutAndTrustSection />

        {/* Services Section */}
        <ServicesSection />

        {/* Call to Action Section */}
        <CTASection onOpenContact={() => scrollToSection('contact')} />

        {/* Contact & Inspection Request Section */}
        <ContactSection />
      </main>

      {/* Footer - No visible admin button */}
      <Footer />

      {/* Floating Quick WhatsApp Button */}
      <a
        href={getWhatsAppUrl()}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-40 px-4 py-3 rounded-full bg-[#25D366] hover:bg-[#20ba5a] text-black font-bold text-xs tracking-wider shadow-2xl shadow-[#25D366]/40 flex items-center gap-2 transition-transform hover:scale-105 cursor-pointer group"
        aria-label="Direct WhatsApp Chat: 09024971419"
        title="Chat with HERO REAL ESTATE on WhatsApp: 09024971419"
      >
        <MessageSquare className="w-5 h-5 fill-current" />
        <span className="font-mono font-bold text-xs">09024971419</span>
      </a>

      {/* Scroll to Top Button */}
      {showScrollTop && (
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="fixed bottom-6 left-6 z-40 p-3 rounded-full bg-[#161616]/90 border border-neutral-700 hover:border-[#F5BD45] text-neutral-300 hover:text-[#F5BD45] transition-all cursor-pointer backdrop-blur-sm shadow-xl"
          aria-label="Scroll to top"
        >
          <ArrowUp className="w-4 h-4" />
        </button>
      )}

      {/* Property Details Modal */}
      <PropertyDetailModal
        property={selectedProperty}
        onClose={() => setSelectedProperty(null)}
      />

      {/* Admin Login Modal (Triggered via browser URL #/admin or #admin) */}
      <AdminLoginModal
        isOpen={isLoginModalOpen}
        onClose={handleCloseLoginModal}
        onLoginSuccess={handleLoginSuccess}
      />

    </div>
  );
}
