// High-fidelity generated luxury assets for HERO REAL ESTATE
export const IMAGES = {
  heroMansion: '/src/assets/images/hero_luxury_mansion_1792834141681.jpg',
  lekkiDuplex: '/src/assets/images/property_lekki_duplex_1792834142472.jpg',
  viApartment: '/src/assets/images/property_vi_apartment_1792834142916.jpg',
  abujaBungalow: '/src/assets/images/property_abuja_bungalow_1792834142908.jpg',
  lagosSkyline: '/src/assets/images/cta_lagos_skyline_1792834143599.jpg',
};
