import { ShieldCheck, Layers, Award, Headphones, FileCheck2, Users, Building, CheckCircle } from 'lucide-react';

export default function AboutAndTrustSection() {
  const pillars = [
    {
      icon: ShieldCheck,
      title: 'Trusted and Secure',
      description: 'Every property in our portfolio undergoes thorough legal title verification—ensuring authentic Certificate of Occupancy (C of O), Governor’s Consent, and unencumbered ownership.'
    },
    {
      icon: Layers,
      title: 'Wide Range of Properties',
      description: 'From luxury waterfront penthouses in Victoria Island and bespoke Lekki duplexes to serene Abuja estates and high-yield commercial lands across Nigeria.'
    },
    {
      icon: Award,
      title: 'Professional Support',
      description: 'Our licensed real estate consultants, valuers, and legal partners guide you through tenancy agreements, conveyance documentation, and handover processes seamlessly.'
    },
    {
      icon: Headphones,
      title: 'Customer Service',
      description: 'Dedicated client managers provide fast responses, virtual video walkthroughs, and escorted on-site physical inspections anywhere in Nigeria.'
    }
  ];

  const metrics = [
    { label: 'Verified Properties', value: '500+' },
    { label: 'Closed Transactions', value: '₦18B+' },
    { label: 'States Covered', value: '36 States' },
    { label: 'Client Satisfaction', value: '99.4%' }
  ];

  return (
    <section id="about" className="py-24 bg-[#0a0a0a] border-t border-neutral-900 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#F5BD45] uppercase tracking-widest mb-3">
            <span>Integrity & Excellence</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight">
            Your Trusted Real Estate Partner
          </h2>
          <p className="mt-4 text-base sm:text-lg text-neutral-300 leading-relaxed font-normal">
            We provide top-quality properties, transparent deals and professional services to make your real estate journey easy and stress-free.
          </p>
        </div>

        {/* 4 Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {pillars.map((pillar, index) => {
            const Icon = pillar.icon;
            return (
              <div
                key={index}
                className="bg-[#111111] border border-neutral-800/90 rounded-2xl p-6 hover:border-[#F5BD45]/40 transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#1C1608] to-[#0D0B05] border border-[#F5BD45]/30 flex items-center justify-center text-[#F5BD45] mb-5 shadow-[0_0_15px_rgba(245,189,69,0.1)]">
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2">
                    {pillar.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">
                    {pillar.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-neutral-800/60 flex items-center gap-2 text-xs text-[#F5BD45]">
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span className="font-medium">HERO Quality Guarantee</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Quantified Impact Strip */}
        <div className="bg-[#121212] border border-neutral-800 rounded-2xl p-8 sm:p-10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center divide-y md:divide-y-0 md:divide-x divide-neutral-800">
            {metrics.map((item, idx) => (
              <div key={idx} className={idx > 0 ? 'pt-4 md:pt-0' : ''}>
                <div className="text-3xl sm:text-4xl font-extrabold text-[#F5BD45] font-display tabular-nums tracking-tight mb-1">
                  {item.value}
                </div>
                <div className="text-xs uppercase tracking-wider text-neutral-400 font-medium">
                  {item.label}
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}
