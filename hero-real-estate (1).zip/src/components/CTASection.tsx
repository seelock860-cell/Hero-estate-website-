import { MessageSquare, PhoneCall, Calendar } from 'lucide-react';
import { IMAGES } from '../assets/images.ts';
import { getWhatsAppUrl, COMPANY_PHONE_DISPLAY } from '../utils/format.ts';

export default function CTASection({ onOpenContact }: { onOpenContact: () => void }) {
  return (
    <section className="relative py-24 sm:py-32 overflow-hidden border-t border-neutral-900">
      {/* Nigerian City Skyline Background */}
      <div className="absolute inset-0 z-0">
        <img
          src={IMAGES.lagosSkyline}
          alt="Lagos Nigeria Waterfront Skyline at dusk"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center"
        />
        {/* Deep luxury black gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/85 to-black/70" />
        <div className="absolute inset-0 bg-[#080808]/50" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center flex flex-col items-center">
        
        {/* Eyebrow */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#1C1608]/90 border border-[#F5BD45]/40 text-xs font-semibold text-[#F5BD45] uppercase tracking-wider mb-6">
          <span>Seamless Property Acquisition in Nigeria</span>
        </div>

        {/* Headline */}
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight max-w-3xl text-balance">
          Ready to Find Your Next Property?
        </h2>

        {/* Supporting Text */}
        <p className="mt-4 text-base sm:text-lg text-neutral-300 max-w-xl font-normal leading-relaxed">
          Contact us today and let's get you settled. Our senior property consultants are standing by to assist you across Nigeria.
        </p>

        {/* Action Buttons */}
        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4 w-full sm:w-auto">
          {/* Gold WhatsApp Button */}
          <a
            href={getWhatsAppUrl(undefined, 'Hello HERO REAL ESTATE, I am ready to find my next property in Nigeria.')}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-8 py-4 rounded-xl bg-[#F5BD45] hover:bg-[#e5ac33] text-black font-extrabold text-sm uppercase tracking-wider transition-all duration-200 shadow-xl shadow-[#F5BD45]/25 cursor-pointer"
          >
            <MessageSquare className="w-5 h-5 fill-current" />
            <span>Chat on WhatsApp: 09024971419</span>
          </a>

          {/* Book Inspection / Contact Form Button */}
          <button
            onClick={onOpenContact}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-4 rounded-xl bg-neutral-900/90 hover:bg-neutral-800 text-white font-bold text-sm tracking-wider uppercase border border-neutral-700 hover:border-[#F5BD45]/50 transition-colors cursor-pointer backdrop-blur-sm"
          >
            <Calendar className="w-4 h-4 text-[#F5BD45]" />
            <span>Book an Inspection</span>
          </button>
        </div>

        {/* Direct Call Line */}
        <div className="mt-8 flex items-center gap-2 text-xs sm:text-sm text-neutral-400">
          <PhoneCall className="w-4 h-4 text-[#F5BD45]" />
          <span>Prefer a direct phone call? Reach us:</span>
          <a href={`tel:${COMPANY_PHONE_DISPLAY.replace(/\s+/g, '')}`} className="text-white font-semibold hover:text-[#F5BD45] underline">
            {COMPANY_PHONE_DISPLAY}
          </a>
        </div>

      </div>
    </section>
  );
}
