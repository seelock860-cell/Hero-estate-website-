import { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send, MessageSquare, CheckCircle } from 'lucide-react';
import { COMPANY_PHONE_DISPLAY, COMPANY_EMAIL, getWhatsAppUrl } from '../utils/format.ts';
import { api } from '../services/api.ts';

export default function ContactSection() {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [propertyInterest, setPropertyInterest] = useState('Rent in Lagos');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || !message.trim()) {
      setErrorMsg('Please complete all required fields.');
      return;
    }

    setSubmitting(true);
    setErrorMsg(null);
    try {
      await api.submitEnquiry({
        customer_name: name,
        phone_number: phone,
        email,
        message: `[Interest: ${propertyInterest}]\n${message}`
      });
      setSubmitted(true);
      setName('');
      setPhone('');
      setEmail('');
      setMessage('');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to submit enquiry';
      setErrorMsg(msg);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-24 bg-[#080808] border-t border-neutral-900 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
          
          {/* Left Column: Office Information */}
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#F5BD45] uppercase tracking-widest mb-3">
              <span>Nationwide Operations</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight mb-4">
              Get in Touch with HERO REAL ESTATE
            </h2>
            <p className="text-sm sm:text-base text-neutral-400 leading-relaxed mb-8">
              Whether you are looking to rent a luxury apartment, purchase an executive family home, or enlist our property management services, our experienced advisors are here to guide you.
            </p>

            <div className="space-y-6">
              
              {/* Lagos Headquarters */}
              <div className="bg-[#111111] border border-neutral-800 rounded-xl p-5 flex items-start gap-4">
                <div className="p-3 rounded-lg bg-neutral-900 text-[#F5BD45] shrink-0 border border-neutral-800">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white mb-1">Lagos Head Office</h4>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    Plot 12, Admiralty Way, Lekki Phase 1 / Victoria Island Corridor, Lagos, Nigeria.
                  </p>
                </div>
              </div>

              {/* Abuja District Office */}
              <div className="bg-[#111111] border border-neutral-800 rounded-xl p-5 flex items-start gap-4">
                <div className="p-3 rounded-lg bg-neutral-900 text-[#F5BD45] shrink-0 border border-neutral-800">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white mb-1">Abuja FCT Branch</h4>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    Maitama Commercial District, Gana Street, Abuja FCT, Nigeria.
                  </p>
                </div>
              </div>

              {/* Contact Channels */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-[#111111] border border-neutral-800 rounded-xl p-4 flex items-center gap-3">
                  <Phone className="w-4 h-4 text-[#F5BD45] shrink-0" />
                  <div>
                    <span className="block text-[11px] text-neutral-500 uppercase tracking-wider">Direct / WhatsApp</span>
                    <a href="tel:09024971419" className="text-xs font-semibold text-white hover:text-[#F5BD45]">
                      0902 497 1419
                    </a>
                  </div>
                </div>

                <div className="bg-[#111111] border border-neutral-800 rounded-xl p-4 flex items-center gap-3">
                  <Mail className="w-4 h-4 text-[#F5BD45] shrink-0" />
                  <div>
                    <span className="block text-[11px] text-neutral-500 uppercase tracking-wider">Email Desk</span>
                    <a href={`mailto:${COMPANY_EMAIL}`} className="text-xs font-semibold text-white hover:text-[#F5BD45]">
                      {COMPANY_EMAIL}
                    </a>
                  </div>
                </div>
              </div>

              {/* Direct WhatsApp Box */}
              <div className="p-5 rounded-xl bg-gradient-to-r from-[#17130a] to-[#0f0e08] border border-[#F5BD45]/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <h4 className="text-sm font-bold text-[#F5BD45] flex items-center gap-2">
                    <MessageSquare className="w-4 h-4" />
                    Instant WhatsApp Support
                  </h4>
                  <p className="text-xs text-white font-mono mt-1 font-semibold">
                    09024971419
                  </p>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    Direct line with our senior property managers. Average response time: under 5 minutes.
                  </p>
                </div>
                <a
                  href={getWhatsAppUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 bg-[#25D366] hover:bg-[#20ba5a] text-black font-bold text-xs uppercase tracking-wider rounded-lg transition-colors shrink-0 shadow-md flex items-center gap-1.5"
                >
                  <MessageSquare className="w-3.5 h-3.5 fill-current" />
                  <span>Message 09024971419</span>
                </a>
              </div>

            </div>
          </div>

          {/* Right Column: Interactive Form */}
          <div className="bg-[#111111] border border-neutral-800 rounded-2xl p-6 sm:p-8">
            <h3 className="text-xl font-bold text-white mb-2">
              Send an Enquiry or Book Inspection
            </h3>
            <p className="text-xs sm:text-sm text-neutral-400 mb-6">
              Complete this form and our designated regional property manager will reach out to you within the hour.
            </p>

            {submitted ? (
              <div className="p-6 bg-[#161d15] border border-emerald-500/50 rounded-xl text-center space-y-3">
                <CheckCircle className="w-10 h-10 text-emerald-400 mx-auto" />
                <h4 className="text-base font-bold text-white">Enquiry Received Successfully</h4>
                <p className="text-xs text-neutral-300">
                  Thank you for reaching out to HERO REAL ESTATE. Your enquiry has been routed to our inspection desk.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="mt-4 px-4 py-2 bg-[#F5BD45] text-black font-bold text-xs uppercase tracking-wider rounded-lg hover:bg-[#e5ac33]"
                >
                  Send Another Message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                {errorMsg && (
                  <div className="p-3 bg-red-950/60 border border-red-500/50 rounded-lg text-xs text-red-300">
                    {errorMsg}
                  </div>
                )}

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="Chief Emeka Okafor"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-[#181818] border border-neutral-700 focus:border-[#F5BD45] rounded-lg px-3.5 py-2.5 text-sm text-white focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-neutral-300 mb-1">Phone Number (WhatsApp) *</label>
                    <input
                      type="tel"
                      required
                      placeholder="+234 803 000 0000"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full bg-[#181818] border border-neutral-700 focus:border-[#F5BD45] rounded-lg px-3.5 py-2.5 text-sm text-white focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-neutral-300 mb-1">Email Address</label>
                    <input
                      type="email"
                      placeholder="emeka@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-[#181818] border border-neutral-700 focus:border-[#F5BD45] rounded-lg px-3.5 py-2.5 text-sm text-white focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Primary Interest</label>
                  <select
                    value={propertyInterest}
                    onChange={(e) => setPropertyInterest(e.target.value)}
                    className="w-full bg-[#181818] border border-neutral-700 focus:border-[#F5BD45] rounded-lg px-3.5 py-2.5 text-sm text-white focus:outline-none"
                  >
                    <option value="Rent in Lagos">Rent a Property in Lagos (Lekki, VI, Ikoyi)</option>
                    <option value="Rent in Abuja">Rent a Property in Abuja (Maitama, Guzape)</option>
                    <option value="Rent in Port Harcourt">Rent a Property in Port Harcourt</option>
                    <option value="Buy Luxury House">Purchase a Luxury House / Villa</option>
                    <option value="Buy Land">Purchase Verified Land with Title</option>
                    <option value="Property Management">Request Property Management for my Asset</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">Message or Inspection Availability *</label>
                  <textarea
                    rows={4}
                    required
                    placeholder="Tell us about your budget, preferred move-in date or desired inspection day..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full bg-[#181818] border border-neutral-700 focus:border-[#F5BD45] rounded-lg px-3.5 py-2.5 text-sm text-white focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-3 rounded-lg bg-[#F5BD45] hover:bg-[#e5ac33] text-black font-bold text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 shadow-md"
                >
                  <Send className="w-4 h-4" />
                  <span>{submitting ? 'Submitting Enquiry...' : 'Submit Inspection Request'}</span>
                </button>
              </form>
            )}
          </div>

        </div>

      </div>
    </section>
  );
}
