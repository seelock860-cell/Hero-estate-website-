import Logo from './Logo.tsx';
import { getWhatsAppUrl, COMPANY_PHONE_DISPLAY, COMPANY_EMAIL } from '../utils/format.ts';
import { Phone, Mail, MapPin, MessageSquare } from 'lucide-react';

export default function Footer({ onOpenAdmin }: { onOpenAdmin?: () => void }) {
  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#050505] border-t border-neutral-900 text-neutral-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 mb-12">
          
          {/* Brand & Summary */}
          <div className="lg:col-span-2 space-y-4">
            <Logo />
            <p className="text-neutral-400 text-xs sm:text-sm leading-relaxed max-w-sm pt-2">
              HERO REAL ESTATE is Nigeria's foremost luxury property advisory. Delivering verified luxury homes, apartments, and commercial investments across Lagos, Abuja, Port Harcourt, and nationwide.
            </p>
            <div className="pt-2">
              <a
                href={getWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-neutral-900 border border-neutral-800 text-xs text-[#F5BD45] hover:border-[#F5BD45]/50 transition-colors"
              >
                <MessageSquare className="w-3.5 h-3.5 fill-current" />
                <span>WhatsApp: 09024971419</span>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="text-white font-bold text-xs uppercase tracking-wider">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => scrollTo('hero')} className="hover:text-[#F5BD45] transition-colors cursor-pointer">
                  Home
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('properties')} className="hover:text-[#F5BD45] transition-colors cursor-pointer">
                  Featured Properties
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('about')} className="hover:text-[#F5BD45] transition-colors cursor-pointer">
                  About Us & Trust
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('services')} className="hover:text-[#F5BD45] transition-colors cursor-pointer">
                  Our Services
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('contact')} className="hover:text-[#F5BD45] transition-colors cursor-pointer">
                  Book an Inspection
                </button>
              </li>
            </ul>
          </div>

          {/* Our Services */}
          <div className="space-y-3">
            <h4 className="text-white font-bold text-xs uppercase tracking-wider">Our Services</h4>
            <ul className="space-y-2">
              <li>
                <a href="#services" className="hover:text-[#F5BD45] transition-colors">House Rentals</a>
              </li>
              <li>
                <a href="#services" className="hover:text-[#F5BD45] transition-colors">Apartment Rentals</a>
              </li>
              <li>
                <a href="#services" className="hover:text-[#F5BD45] transition-colors">Property Sales</a>
              </li>
              <li>
                <a href="#services" className="hover:text-[#F5BD45] transition-colors">Land Sales</a>
              </li>
              <li>
                <a href="#services" className="hover:text-[#F5BD45] transition-colors">Property Management</a>
              </li>
              <li>
                <a href="#services" className="hover:text-[#F5BD45] transition-colors">Real Estate Consultancy</a>
              </li>
            </ul>
          </div>

          {/* Contact Information */}
          <div className="space-y-3">
            <h4 className="text-white font-bold text-xs uppercase tracking-wider">Contact Desk</h4>
            <ul className="space-y-2.5">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#F5BD45] shrink-0 mt-0.5" />
                <span>Admiralty Way, Lekki Phase 1, Lagos, Nigeria</span>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#F5BD45] shrink-0 mt-0.5" />
                <span>Gana Street, Maitama, Abuja FCT</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#F5BD45] shrink-0" />
                <a href="tel:+2348039870000" className="hover:text-[#F5BD45]">{COMPANY_PHONE_DISPLAY}</a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-[#F5BD45] shrink-0" />
                <a href={`mailto:${COMPANY_EMAIL}`} className="hover:text-[#F5BD45]">{COMPANY_EMAIL}</a>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-neutral-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-neutral-500 text-[11px]">
          <div>
            © {new Date().getFullYear()} HERO REAL ESTATE Nigeria. All rights reserved. Safe. Trusted. Reliable.
          </div>
          <div className="flex items-center gap-6">
            <span>CAC Registered Real Estate Entity</span>
            <span>·</span>
            <span>Serving All 36 States in Nigeria</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
