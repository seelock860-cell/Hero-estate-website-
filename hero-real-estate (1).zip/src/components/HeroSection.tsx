import { useState } from 'react';
import { Search, Home, Building2, MapPin, CheckCircle2, MessageSquare } from 'lucide-react';
import { IMAGES } from '../assets/images.ts';
import { getWhatsAppUrl } from '../utils/format.ts';

interface HeroSectionProps {
  onSearch: (filters: {
    location?: string;
    property_type?: string;
    priceRange?: string;
    listing_type?: string;
  }) => void;
}

export default function HeroSection({ onSearch }: HeroSectionProps) {
  const [location, setLocation] = useState('all');
  const [propertyType, setPropertyType] = useState('all');
  const [priceRange, setPriceRange] = useState('all');
  const [listingType, setListingType] = useState<'all' | 'rent' | 'sale'>('all');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch({
      location: location === 'all' ? undefined : location,
      property_type: propertyType === 'all' ? undefined : propertyType,
      priceRange: priceRange === 'all' ? undefined : priceRange,
      listing_type: listingType === 'all' ? undefined : listingType
    });

    const el = document.getElementById('properties');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="hero" className="relative min-h-[92vh] flex items-center justify-center overflow-hidden">
      {/* Background Mansion Image with Luxury Gradient Scrim */}
      <div className="absolute inset-0 z-0">
        <img
          src={IMAGES.heroMansion}
          alt="Modern luxury mansion at sunset in Nigeria"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center scale-105 transform duration-1000"
        />
        {/* Anti-slop measured dark scrim for high typographic legibility */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#080808] via-[#080808]/75 to-[#080808]/40" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(245,189,69,0.06)_0,transparent_70%)]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 w-full flex flex-col items-center text-center">
        
        {/* Subtle Brand Kicker & Direct WhatsApp Hotline */}
        <div className="flex flex-wrap items-center justify-center gap-3 mb-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-neutral-900/80 border border-[#F5BD45]/30 text-xs text-[#F5BD45] font-medium tracking-wide uppercase backdrop-blur-sm">
            <span>Nigeria's Premier Luxury Real Estate Agency</span>
          </div>
          <a
            href={getWhatsAppUrl()}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/70 border border-emerald-500/40 text-xs text-emerald-300 font-semibold backdrop-blur-sm hover:bg-emerald-900/70 transition-colors"
          >
            <MessageSquare className="w-3.5 h-3.5 fill-current text-emerald-400" />
            <span>WhatsApp: 09024971419</span>
          </a>
        </div>

        {/* Main Headline */}
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight max-w-4xl text-balance leading-tight">
          Find Your Dream Home in <span className="text-[#F5BD45] font-display">Nigeria</span>
        </h1>

        {/* Supporting Text */}
        <p className="mt-5 text-base sm:text-lg text-neutral-300 max-w-2xl font-normal leading-relaxed">
          We help you find the perfect home, apartment or rental property across all states in Nigeria. Safe. Trusted. Reliable.
        </p>

        {/* Three Highlights */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-6 sm:gap-10 text-xs sm:text-sm text-neutral-200">
          <div className="flex items-center gap-2 bg-black/40 backdrop-blur-md px-3.5 py-1.5 rounded-lg border border-neutral-800/80">
            <CheckCircle2 className="w-4 h-4 text-[#F5BD45]" />
            <span className="font-medium">Houses for Rent</span>
          </div>
          <div className="flex items-center gap-2 bg-black/40 backdrop-blur-md px-3.5 py-1.5 rounded-lg border border-neutral-800/80">
            <CheckCircle2 className="w-4 h-4 text-[#F5BD45]" />
            <span className="font-medium">Apartments for Rent</span>
          </div>
          <div className="flex items-center gap-2 bg-black/40 backdrop-blur-md px-3.5 py-1.5 rounded-lg border border-neutral-800/80">
            <CheckCircle2 className="w-4 h-4 text-[#F5BD45]" />
            <span className="font-medium">Properties Across Nigeria</span>
          </div>
        </div>

        {/* Integrated Search Bar Box */}
        <div className="mt-12 w-full max-w-4xl bg-[#111111]/95 backdrop-blur-xl border border-neutral-800 rounded-2xl p-4 sm:p-6 shadow-2xl shadow-black/80 text-left">
          {/* Rent / Sale Tabs */}
          <div className="flex items-center gap-2 mb-4 border-b border-neutral-800/80 pb-3">
            <button
              type="button"
              onClick={() => setListingType('all')}
              className={`px-4 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                listingType === 'all'
                  ? 'bg-[#F5BD45] text-black shadow-sm'
                  : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
              }`}
            >
              All Listings
            </button>
            <button
              type="button"
              onClick={() => setListingType('rent')}
              className={`px-4 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                listingType === 'rent'
                  ? 'bg-[#F5BD45] text-black shadow-sm'
                  : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
              }`}
            >
              For Rent
            </button>
            <button
              type="button"
              onClick={() => setListingType('sale')}
              className={`px-4 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                listingType === 'sale'
                  ? 'bg-[#F5BD45] text-black shadow-sm'
                  : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
              }`}
            >
              For Sale
            </button>
          </div>

          <form onSubmit={handleSearchSubmit} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 items-end">
            
            {/* Location */}
            <div>
              <label className="block text-xs font-medium text-neutral-400 mb-1.5">
                <span className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-[#F5BD45]" />
                  Location
                </span>
              </label>
              <select
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full bg-[#181818] border border-neutral-700 focus:border-[#F5BD45] rounded-lg px-3 py-2.5 text-sm text-white focus:outline-none transition-colors"
              >
                <option value="all">All Locations (Nigeria)</option>
                <option value="Lagos">Lagos State (Lekki, VI, Ikoyi, Ikeja)</option>
                <option value="Abuja FCT">Abuja FCT (Maitama, Guzape, Wuse)</option>
                <option value="Rivers">Rivers (Port Harcourt)</option>
                <option value="Oyo">Oyo State (Ibadan)</option>
                <option value="Ogun">Ogun State</option>
              </select>
            </div>

            {/* Property Type */}
            <div>
              <label className="block text-xs font-medium text-neutral-400 mb-1.5">
                <span className="flex items-center gap-1.5">
                  <Home className="w-3.5 h-3.5 text-[#F5BD45]" />
                  Property Type
                </span>
              </label>
              <select
                value={propertyType}
                onChange={(e) => setPropertyType(e.target.value)}
                className="w-full bg-[#181818] border border-neutral-700 focus:border-[#F5BD45] rounded-lg px-3 py-2.5 text-sm text-white focus:outline-none transition-colors"
              >
                <option value="all">All Property Types</option>
                <option value="duplex">Duplex</option>
                <option value="apartment">Apartment / Flat</option>
                <option value="bungalow">Bungalow</option>
                <option value="terrace">Terrace Duplex</option>
                <option value="mansion">Mansion</option>
                <option value="penthouse">Penthouse</option>
              </select>
            </div>

            {/* Price Range */}
            <div>
              <label className="block text-xs font-medium text-neutral-400 mb-1.5">
                <span className="flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5 text-[#F5BD45]" />
                  Price Range
                </span>
              </label>
              <select
                value={priceRange}
                onChange={(e) => setPriceRange(e.target.value)}
                className="w-full bg-[#181818] border border-neutral-700 focus:border-[#F5BD45] rounded-lg px-3 py-2.5 text-sm text-white focus:outline-none transition-colors"
              >
                <option value="all">Any Price</option>
                <option value="under-1m">Under ₦1,000,000</option>
                <option value="1m-2.5m">₦1,000,000 – ₦2,500,000</option>
                <option value="2.5m-5m">₦2,500,000 – ₦5,000,000</option>
                <option value="5m-50m">₦5,000,000 – ₦50,000,000</option>
                <option value="50m-plus">₦50,000,000+ (Luxury Sales)</option>
              </select>
            </div>

            {/* Search Button */}
            <div>
              <button
                type="submit"
                className="w-full h-[42px] inline-flex items-center justify-center gap-2 bg-[#F5BD45] hover:bg-[#e5ac33] text-black font-semibold text-sm rounded-lg transition-colors shadow-lg shadow-[#F5BD45]/20 cursor-pointer"
              >
                <Search className="w-4 h-4 stroke-[2.5]" />
                <span>Search Properties</span>
              </button>
            </div>

          </form>
        </div>

      </div>
    </section>
  );
}
