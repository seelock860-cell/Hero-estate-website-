export default function Logo({ className = '', iconOnly = false }: { className?: string; iconOnly?: boolean }) {
  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Gold House Shaped Icon */}
      <div className="relative flex items-center justify-center w-10 h-10 rounded-lg bg-gradient-to-br from-[#1C1608] to-[#0D0B05] border border-[#F5BD45]/40 shadow-[0_0_15px_rgba(245,189,69,0.15)] shrink-0">
        <svg
          viewBox="0 0 40 40"
          className="w-6 h-6 text-[#F5BD45]"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* House Roof & Body */}
          <path
            d="M20 6L6 17V33C6 33.5523 6.44772 34 7 34H33C33.5523 34 34 33.5523 34 33V17L20 6Z"
            stroke="url(#goldGrad)"
            strokeWidth="2.2"
            strokeLinejoin="round"
          />
          {/* Stylized 'H' / Arch inside */}
          <path
            d="M14 20V29M26 20V29M14 24.5H26"
            stroke="url(#goldGrad)"
            strokeWidth="2"
            strokeLinecap="round"
          />
          {/* Chimney Accent */}
          <path
            d="M27 10.5V8H30V13"
            stroke="url(#goldGrad)"
            strokeWidth="1.8"
            strokeLinecap="round"
          />
          <defs>
            <linearGradient id="goldGrad" x1="6" y1="6" x2="34" y2="34" gradientUnits="userSpaceOnUse">
              <stop stopColor="#FFE59E" />
              <stop offset="0.5" stopColor="#F5BD45" />
              <stop offset="1" stopColor="#C99424" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      {!iconOnly && (
        <div className="flex flex-col">
          <span className="font-extrabold tracking-wider text-white text-lg leading-none font-display">
            HERO
          </span>
          <span className="text-[10px] tracking-[0.26em] text-[#F5BD45] font-semibold uppercase mt-0.5">
            REAL ESTATE
          </span>
        </div>
      )}
    </div>
  );
}
