import { useState } from 'react';
import { Search, MessageSquare, Menu, X, Phone } from 'lucide-react';
import Logo from './Logo.tsx';
import { getWhatsAppUrl, COMPANY_PHONE_DISPLAY } from '../utils/format.ts';

interface NavbarProps {
  onOpenSearch: () => void;
}

export default function Navbar({ onOpenSearch }: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollTo = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#080808]/90 backdrop-blur-md border-b border-[#242424]">
      {/* Top Bar Contract: Zone 1 (Wordmark) — Zone 2 (4-5 Nav Links) — Zone 3 (Primary Action) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-8">
        
        {/* Zone 1: Brand Wordmark */}
        <a href="#" className="whitespace-nowrap shrink-0 group">
          <Logo />
        </a>

        {/* Zone 2: Navigation Links (Single-line, unboxed, subtle hover) */}
        <nav className="hidden lg:flex items-center gap-8 text-sm font-medium text-neutral-300">
          <button
            onClick={() => scrollTo('hero')}
            className="hover:text-[#F5BD45] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Home
          </button>
          <button
            onClick={() => scrollTo('properties')}
            className="hover:text-[#F5BD45] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Properties
          </button>
          <button
            onClick={() => scrollTo('about')}
            className="hover:text-[#F5BD45] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            About Us
          </button>
          <button
            onClick={() => scrollTo('services')}
            className="hover:text-[#F5BD45] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Services
          </button>
          <button
            onClick={() => scrollTo('contact')}
            className="hover:text-[#F5BD45] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Contact
          </button>
        </nav>

        {/* Zone 3: Actions (Search, WhatsApp Contact) - Admin button hidden per request */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Quick Search */}
          <button
            onClick={onOpenSearch}
            className="p-2 text-neutral-400 hover:text-white hover:bg-neutral-900 rounded-lg transition-colors cursor-pointer"
            aria-label="Search properties"
            title="Search properties"
          >
            <Search className="w-5 h-5" />
          </button>

          {/* WhatsApp Contact Button with Visible Number */}
          <a
            href={getWhatsAppUrl()}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex items-center gap-2 px-3.5 py-2 text-xs font-bold tracking-wider text-black bg-[#F5BD45] hover:bg-[#e5ac33] transition-all duration-200 rounded-lg shadow-[0_0_12px_rgba(245,189,69,0.25)] whitespace-nowrap shrink-0 cursor-pointer"
            title="Chat with us on WhatsApp: 09024971419"
          >
            <MessageSquare className="w-4 h-4 fill-current" />
            <span>WhatsApp: 09024971419</span>
          </a>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-neutral-300 hover:text-white rounded-lg hover:bg-neutral-900 cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#0e0e0e] border-b border-neutral-800 px-6 py-6 space-y-4">
          <div className="flex flex-col space-y-3 text-sm font-medium">
            <button
              onClick={() => scrollTo('hero')}
              className="text-left py-2 text-neutral-200 hover:text-[#F5BD45]"
            >
              Home
            </button>
            <button
              onClick={() => scrollTo('properties')}
              className="text-left py-2 text-neutral-200 hover:text-[#F5BD45]"
            >
              Properties for Rent & Sale
            </button>
            <button
              onClick={() => scrollTo('about')}
              className="text-left py-2 text-neutral-200 hover:text-[#F5BD45]"
            >
              About HERO Real Estate
            </button>
            <button
              onClick={() => scrollTo('services')}
              className="text-left py-2 text-neutral-200 hover:text-[#F5BD45]"
            >
              Our Services
            </button>
            <button
              onClick={() => scrollTo('contact')}
              className="text-left py-2 text-neutral-200 hover:text-[#F5BD45]"
            >
              Contact Us
            </button>
          </div>

          <div className="pt-4 border-t border-neutral-800 flex flex-col gap-3">
            <a
              href={getWhatsAppUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-3 text-xs font-semibold uppercase tracking-wider text-black bg-[#F5BD45] hover:bg-[#e5ac33] rounded-lg transition-colors"
            >
              <MessageSquare className="w-4 h-4 fill-current" />
              <span>WhatsApp: 09024971419</span>
            </a>
            <div className="flex items-center justify-between text-xs text-neutral-400 pt-2">
              <span className="flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-[#F5BD45]" />
                {COMPANY_PHONE_DISPLAY}
              </span>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
