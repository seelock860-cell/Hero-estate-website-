import { useState } from 'react';
import { Bed, Bath, Car, MapPin, ArrowRight } from 'lucide-react';
import type { Property } from '../types.ts';
import { formatNaira } from '../utils/format.ts';

interface PropertyCardProps {
  property: Property;
  onViewDetails: (property: Property) => void;
}

export default function PropertyCard({ property, onViewDetails }: PropertyCardProps) {
  const [imgError, setImgError] = useState(false);
  const primaryImage = property.image_urls?.[0] || '';

  return (
    <div className="group bg-[#111111] border border-neutral-800/90 hover:border-[#F5BD45]/50 rounded-xl overflow-hidden transition-all duration-300 flex flex-col h-full hover:shadow-xl hover:shadow-black/60">
      
      {/* Photograph Container */}
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-neutral-900">
        {!imgError && primaryImage ? (
          <img
            src={primaryImage}
            alt={property.title}
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          /* Styled Fallback */
          <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-neutral-900 to-[#181818] p-6 text-center">
            <span className="text-[#F5BD45] font-display text-2xl font-bold">HERO</span>
            <span className="text-xs text-neutral-400 mt-1">{property.city}, {property.state}</span>
          </div>
        )}

        {/* Listing Status Tag (Rent / Sale / Lease) */}
        <div className="absolute top-3 left-3 flex items-center gap-2">
          <span className={`px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider rounded-md backdrop-blur-md shadow-md ${
            property.listing_type === 'rent'
              ? 'bg-black/75 text-[#F5BD45] border border-[#F5BD45]/40'
              : 'bg-[#F5BD45] text-black font-extrabold'
          }`}>
            For {property.listing_type}
          </span>
          {property.availability_status !== 'available' && (
            <span className="px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider rounded-md bg-neutral-900/90 text-neutral-300 border border-neutral-700">
              {property.availability_status}
            </span>
          )}
        </div>

        {/* Property Type Identifier */}
        <div className="absolute bottom-3 right-3">
          <span className="px-2.5 py-0.5 text-[11px] font-medium capitalize rounded bg-black/60 backdrop-blur-md text-neutral-300 border border-neutral-800">
            {property.property_type}
          </span>
        </div>
      </div>

      {/* Card Content */}
      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          {/* Location Line */}
          <div className="flex items-center gap-1.5 text-xs text-neutral-400 mb-2">
            <MapPin className="w-3.5 h-3.5 text-[#F5BD45] shrink-0" />
            <span className="truncate">{property.city}, {property.state}</span>
          </div>

          {/* Property Title */}
          <h3 className="text-base font-semibold text-white group-hover:text-[#F5BD45] transition-colors line-clamp-1 mb-2">
            {property.title}
          </h3>

          {/* Price in Nigerian Naira (Tabular numerals) */}
          <div className="mb-4">
            <span className="text-xl font-bold text-[#F5BD45] tabular-nums tracking-tight">
              {formatNaira(property.price, property.listing_type === 'rent' ? property.price_period || 'year' : undefined)}
            </span>
          </div>

          {/* Key Specs: Beds, Baths, Parking */}
          <div className="grid grid-cols-3 gap-2 py-3 border-y border-neutral-800/80 text-xs text-neutral-300">
            <div className="flex items-center gap-1.5">
              <Bed className="w-4 h-4 text-neutral-400" />
              <span className="tabular-nums font-medium">{property.bedrooms}</span>
              <span className="text-neutral-400 text-[11px]">Beds</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Bath className="w-4 h-4 text-neutral-400" />
              <span className="tabular-nums font-medium">{property.bathrooms}</span>
              <span className="text-neutral-400 text-[11px]">Baths</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Car className="w-4 h-4 text-neutral-400" />
              <span className="tabular-nums font-medium">{property.parking_spaces}</span>
              <span className="text-neutral-400 text-[11px]">Parks</span>
            </div>
          </div>
        </div>

        {/* Action Button: View Details */}
        <div className="mt-4 pt-1">
          <button
            onClick={() => onViewDetails(property)}
            className="w-full py-2.5 px-4 rounded-lg bg-neutral-900 hover:bg-[#F5BD45] text-neutral-200 hover:text-black font-semibold text-xs tracking-wider uppercase transition-all duration-200 flex items-center justify-center gap-2 border border-neutral-800 hover:border-[#F5BD45] cursor-pointer"
          >
            <span>View Details</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>

    </div>
  );
}
