import { useState } from 'react';
import { X, Bed, Bath, Car, MapPin, Check, MessageSquare, Send, Sparkles, Building, Calendar } from 'lucide-react';
import type { Property } from '../types.ts';
import { formatNaira, getPropertyWhatsAppUrl } from '../utils/format.ts';
import { api } from '../services/api.ts';

interface PropertyDetailModalProps {
  property: Property | null;
  onClose: () => void;
}

export default function PropertyDetailModal({ property, onClose }: PropertyDetailModalProps) {
  if (!property) return null;

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState(
    `Hello HERO REAL ESTATE, I would like to schedule an inspection for "${property.title}" in ${property.city}, ${property.state}. Please contact me.`
  );
  const [submitting, setSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const images = property.image_urls && property.image_urls.length > 0 
    ? property.image_urls 
    : ['/src/assets/images/hero_luxury_mansion_1792834141681.jpg'];

  const handleSubmitEnquiry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || !message.trim()) {
      setSubmitError('Please enter your name, phone number, and message.');
      return;
    }

    setSubmitting(true);
    setSubmitError(null);
    try {
      await api.submitEnquiry({
        customer_name: name,
        phone_number: phone,
        email,
        message,
        property_id: property.id,
        property_title: property.title
      });
      setSubmitSuccess(true);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to submit enquiry';
      setSubmitError(msg);
    } finally {
      setSubmitting(false);
    }
  };

  const whatsappLink = getPropertyWhatsAppUrl(property.title, property.price, `${property.city}, ${property.state}`);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 md:p-6 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div 
        className="relative w-full max-w-4xl bg-[#111111] border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-[#0d0d0d] shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase tracking-wider font-bold text-[#F5BD45] px-2 py-0.5 rounded bg-black/60 border border-[#F5BD45]/30">
              For {property.listing_type}
            </span>
            <span className="text-xs text-neutral-400 capitalize">
              {property.property_type} · {property.availability_status}
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto p-6 space-y-6">
          
          {/* Main Gallery Display */}
          <div className="space-y-3">
            <div className="relative aspect-[16/9] w-full bg-neutral-900 rounded-xl overflow-hidden border border-neutral-800">
              <img
                src={images[activeImageIndex] || images[0]}
                alt={property.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 right-4 bg-black/70 backdrop-blur-md px-3 py-1 rounded-md text-xs text-white border border-neutral-700">
                Photo {activeImageIndex + 1} of {images.length}
              </div>
            </div>

            {/* Thumbnail Navigation Strip */}
            {images.length > 1 && (
              <div className="flex items-center gap-2 overflow-x-auto pb-2">
                {images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`relative w-20 h-14 rounded-lg overflow-hidden shrink-0 border-2 transition-all cursor-pointer ${
                      activeImageIndex === idx ? 'border-[#F5BD45] scale-105' : 'border-transparent opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt={`Thumbnail ${idx + 1}`} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Title, Price and Key Facts */}
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 border-b border-neutral-800 pb-6">
            <div>
              <div className="flex items-center gap-1.5 text-xs text-[#F5BD45] mb-1 font-medium">
                <MapPin className="w-4 h-4 shrink-0" />
                <span>{property.address || `${property.city}, ${property.state}`}</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
                {property.title}
              </h2>
            </div>

            <div className="md:text-right shrink-0">
              <span className="block text-xs uppercase tracking-wider text-neutral-400 font-medium">Price</span>
              <span className="text-2xl sm:text-3xl font-black text-[#F5BD45] tabular-nums">
                {formatNaira(property.price, property.listing_type === 'rent' ? property.price_period || 'year' : undefined)}
              </span>
            </div>
          </div>

          {/* Quick Specs Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-[#181818] p-4 rounded-xl border border-neutral-800/80 text-sm">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-neutral-900 text-[#F5BD45]">
                <Bed className="w-5 h-5" />
              </div>
              <div>
                <span className="block text-xs text-neutral-400">Bedrooms</span>
                <span className="font-bold text-white tabular-nums">{property.bedrooms} Bed</span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-neutral-900 text-[#F5BD45]">
                <Bath className="w-5 h-5" />
              </div>
              <div>
                <span className="block text-xs text-neutral-400">Bathrooms</span>
                <span className="font-bold text-white tabular-nums">{property.bathrooms} Bath</span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-neutral-900 text-[#F5BD45]">
                <Car className="w-5 h-5" />
              </div>
              <div>
                <span className="block text-xs text-neutral-400">Parking</span>
                <span className="font-bold text-white tabular-nums">{property.parking_spaces} Vehicles</span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-neutral-900 text-[#F5BD45]">
                <Building className="w-5 h-5" />
              </div>
              <div>
                <span className="block text-xs text-neutral-400">Category</span>
                <span className="font-bold text-white capitalize">{property.property_type}</span>
              </div>
            </div>
          </div>

          {/* Property Description */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-neutral-300 mb-2">
              Property Description
            </h3>
            <p className="text-neutral-300 text-sm sm:text-base leading-relaxed whitespace-pre-line">
              {property.description}
            </p>
          </div>

          {/* Amenities & Features */}
          {property.amenities && property.amenities.length > 0 && (
            <div>
              <h3 className="text-sm font-semibold uppercase tracking-wider text-neutral-300 mb-3 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#F5BD45]" />
                Amenities & Key Features
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                {property.amenities.map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-xs sm:text-sm text-neutral-200 bg-[#161616] px-3 py-2 rounded-lg border border-neutral-800">
                    <Check className="w-4 h-4 text-[#F5BD45] shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Contact & Enquiry Section */}
          <div className="bg-[#141414] border border-[#F5BD45]/30 rounded-xl p-5 sm:p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-800 pb-4">
              <div>
                <h4 className="text-lg font-bold text-white">Interested in this Property?</h4>
                <p className="text-xs text-neutral-400">
                  Speak directly with our property specialist or send an inspection inquiry below.
                </p>
              </div>

              {/* Instant WhatsApp Action */}
              <a
                href={whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-[#25D366] hover:bg-[#20ba5a] text-black font-bold text-xs uppercase tracking-wider transition-colors shrink-0 shadow-lg shadow-[#25D366]/20 cursor-pointer"
              >
                <MessageSquare className="w-4 h-4 fill-current" />
                <span>Chat on WhatsApp</span>
              </a>
            </div>

            {/* Direct Enquiry Form */}
            {submitSuccess ? (
              <div className="p-4 bg-emerald-950/40 border border-emerald-500/40 rounded-lg text-emerald-200 text-sm">
                <p className="font-semibold mb-1">Thank you for your enquiry!</p>
                <p className="text-xs text-emerald-300">
                  Our HERO REAL ESTATE property consultant has received your message and will call or message you promptly on WhatsApp.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmitEnquiry} className="space-y-3">
                {submitError && (
                  <div className="p-3 bg-red-950/50 border border-red-500/40 rounded-lg text-xs text-red-300">
                    {submitError}
                  </div>
                )}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-neutral-400 mb-1">Full Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Chief Adeleke"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-[#1c1c1c] border border-neutral-700 rounded-lg px-3 py-2 text-sm text-white focus:border-[#F5BD45] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-neutral-400 mb-1">Phone Number (WhatsApp) *</label>
                    <input
                      type="tel"
                      required
                      placeholder="+234 803 000 0000"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full bg-[#1c1c1c] border border-neutral-700 rounded-lg px-3 py-2 text-sm text-white focus:border-[#F5BD45] focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs text-neutral-400 mb-1">Email Address</label>
                  <input
                    type="email"
                    placeholder="your.email@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-[#1c1c1c] border border-neutral-700 rounded-lg px-3 py-2 text-sm text-white focus:border-[#F5BD45] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs text-neutral-400 mb-1">Your Message or Inspection Request *</label>
                  <textarea
                    rows={3}
                    required
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full bg-[#1c1c1c] border border-neutral-700 rounded-lg px-3 py-2 text-sm text-white focus:border-[#F5BD45] focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-2.5 rounded-lg bg-[#F5BD45] hover:bg-[#e5ac33] text-black font-bold text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{submitting ? 'Submitting Enquiry...' : 'Send Enquiry to HERO REAL ESTATE'}</span>
                </button>
              </form>
            )}
          </div>

        </div>

      </div>
    </div>
  );
}
