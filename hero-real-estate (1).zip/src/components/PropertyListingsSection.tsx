import { useState, useEffect } from 'react';
import { Filter, SlidersHorizontal, RefreshCw, Search } from 'lucide-react';
import type { Property, PropertyType, ListingType } from '../types.ts';
import PropertyCard from './PropertyCard.tsx';
import { api } from '../services/api.ts';

interface PropertyListingsSectionProps {
  onViewDetails: (property: Property) => void;
  initialFilters?: {
    location?: string;
    property_type?: string;
    priceRange?: string;
    listing_type?: string;
  };
}

export default function PropertyListingsSection({ onViewDetails, initialFilters }: PropertyListingsSectionProps) {
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Filters state
  const [activeTab, setActiveTab] = useState<ListingType | 'all'>(
    (initialFilters?.listing_type as ListingType) || 'rent'
  );
  const [selectedState, setSelectedState] = useState<string>(initialFilters?.location || 'all');
  const [selectedType, setSelectedType] = useState<string>(initialFilters?.property_type || 'all');
  const [selectedPriceRange, setSelectedPriceRange] = useState<string>(initialFilters?.priceRange || 'all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showFilterDrawer, setShowFilterDrawer] = useState(false);

  // Synchronize when initialFilters change from Hero Search
  useEffect(() => {
    if (initialFilters) {
      if (initialFilters.listing_type) setActiveTab(initialFilters.listing_type as ListingType);
      if (initialFilters.location) setSelectedState(initialFilters.location);
      if (initialFilters.property_type) setSelectedType(initialFilters.property_type);
      if (initialFilters.priceRange) setSelectedPriceRange(initialFilters.priceRange);
    }
  }, [initialFilters]);

  const loadProperties = async () => {
    setLoading(true);
    setError(null);
    try {
      let min_price: number | undefined;
      let max_price: number | undefined;

      if (selectedPriceRange === 'under-1m') {
        max_price = 1000000;
      } else if (selectedPriceRange === '1m-2.5m') {
        min_price = 1000000;
        max_price = 2500000;
      } else if (selectedPriceRange === '2.5m-5m') {
        min_price = 2500000;
        max_price = 5000000;
      } else if (selectedPriceRange === '5m-50m') {
        min_price = 5000000;
        max_price = 50000000;
      } else if (selectedPriceRange === '50m-plus') {
        min_price = 50000000;
      }

      const data = await api.getProperties({
        listing_type: activeTab === 'all' ? undefined : activeTab,
        state: selectedState === 'all' ? undefined : selectedState,
        property_type: selectedType === 'all' ? undefined : selectedType,
        min_price,
        max_price,
        query: searchQuery.trim() || undefined
      });
      setProperties(data);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to load properties';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProperties();
  }, [activeTab, selectedState, selectedType, selectedPriceRange, searchQuery]);

  const resetFilters = () => {
    setActiveTab('all');
    setSelectedState('all');
    setSelectedType('all');
    setSelectedPriceRange('all');
    setSearchQuery('');
  };

  return (
    <section id="properties" className="py-20 bg-[#080808] border-t border-neutral-900 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#F5BD45] uppercase tracking-widest mb-2">
              <span>Curated Portfolio</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              {activeTab === 'rent' ? 'Latest Properties for Rent' : activeTab === 'sale' ? 'Featured Properties for Sale' : 'All Available Properties'}
            </h2>
            <p className="mt-2 text-sm sm:text-base text-neutral-400 max-w-xl">
              Explore verified luxury homes, apartments, and duplexes in prime locations across Nigeria.
            </p>
          </div>

          {/* Listing Type Filter Tabs (Interactive Segmented Control) */}
          <div className="flex items-center p-1 bg-[#141414] rounded-xl border border-neutral-800 self-start md:self-end">
            <button
              onClick={() => setActiveTab('rent')}
              className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all cursor-pointer ${
                activeTab === 'rent'
                  ? 'bg-[#F5BD45] text-black shadow-md'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              For Rent
            </button>
            <button
              onClick={() => setActiveTab('sale')}
              className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all cursor-pointer ${
                activeTab === 'sale'
                  ? 'bg-[#F5BD45] text-black shadow-md'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              For Sale
            </button>
            <button
              onClick={() => setActiveTab('all')}
              className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all cursor-pointer ${
                activeTab === 'all'
                  ? 'bg-[#F5BD45] text-black shadow-md'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              All Types
            </button>
          </div>
        </div>

        {/* Search & Filter Bar */}
        <div className="bg-[#111111] border border-neutral-800 rounded-xl p-4 mb-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            
            {/* Search Input */}
            <div className="relative">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search neighborhood or title..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#181818] border border-neutral-700/80 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-[#F5BD45]"
              />
            </div>

            {/* State Filter */}
            <div>
              <select
                value={selectedState}
                onChange={(e) => setSelectedState(e.target.value)}
                className="w-full bg-[#181818] border border-neutral-700/80 rounded-lg px-3 py-2 text-xs text-neutral-200 focus:outline-none focus:border-[#F5BD45]"
              >
                <option value="all">All States</option>
                <option value="Lagos">Lagos (Lekki, VI, Ikoyi, Ikeja)</option>
                <option value="Abuja FCT">Abuja FCT (Maitama, Guzape)</option>
                <option value="Rivers">Rivers (Port Harcourt)</option>
                <option value="Oyo">Oyo (Ibadan)</option>
                <option value="Ogun">Ogun State</option>
              </select>
            </div>

            {/* Type Filter */}
            <div>
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="w-full bg-[#181818] border border-neutral-700/80 rounded-lg px-3 py-2 text-xs text-neutral-200 focus:outline-none focus:border-[#F5BD45]"
              >
                <option value="all">All Property Categories</option>
                <option value="duplex">Duplex</option>
                <option value="apartment">Apartment</option>
                <option value="bungalow">Bungalow</option>
                <option value="terrace">Terrace Duplex</option>
                <option value="mansion">Mansion</option>
                <option value="penthouse">Penthouse</option>
              </select>
            </div>

            {/* Price Filter */}
            <div className="flex items-center gap-2">
              <select
                value={selectedPriceRange}
                onChange={(e) => setSelectedPriceRange(e.target.value)}
                className="w-full bg-[#181818] border border-neutral-700/80 rounded-lg px-3 py-2 text-xs text-neutral-200 focus:outline-none focus:border-[#F5BD45]"
              >
                <option value="all">Any Price</option>
                <option value="under-1m">Under ₦1,000,000</option>
                <option value="1m-2.5m">₦1,000,000 – ₦2,500,000</option>
                <option value="2.5m-5m">₦2,500,000 – ₦5,000,000</option>
                <option value="5m-50m">₦5,000,000 – ₦50,000,000</option>
                <option value="50m-plus">₦50,000,000+ (Luxury Sales)</option>
              </select>

              {(selectedState !== 'all' || selectedType !== 'all' || selectedPriceRange !== 'all' || searchQuery !== '') && (
                <button
                  onClick={resetFilters}
                  title="Reset filters"
                  className="p-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white shrink-0 cursor-pointer"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
              )}
            </div>

          </div>
        </div>

        {/* Content Area */}
        {loading ? (
          <div className="py-24 text-center">
            <div className="inline-block w-8 h-8 border-2 border-[#F5BD45] border-t-transparent rounded-full animate-spin mb-4" />
            <p className="text-sm text-neutral-400">Loading verified properties...</p>
          </div>
        ) : error ? (
          <div className="py-16 text-center bg-[#141414] border border-neutral-800 rounded-xl p-8">
            <p className="text-red-400 mb-3">{error}</p>
            <button
              onClick={loadProperties}
              className="px-4 py-2 bg-[#F5BD45] text-black text-xs font-bold uppercase rounded-lg hover:bg-[#e5ac33]"
            >
              Try Again
            </button>
          </div>
        ) : properties.length === 0 ? (
          <div className="py-16 text-center bg-[#111111] border border-neutral-800 rounded-xl p-8">
            <h3 className="text-lg font-bold text-white mb-2">No Properties Found</h3>
            <p className="text-sm text-neutral-400 max-w-md mx-auto mb-6">
              We couldn't find any properties matching your current filter criteria. Try adjusting the location or price parameters.
            </p>
            <button
              onClick={resetFilters}
              className="px-5 py-2.5 bg-[#F5BD45] text-black font-bold text-xs uppercase tracking-wider rounded-lg hover:bg-[#e5ac33] cursor-pointer"
            >
              Reset All Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {properties.map((prop) => (
              <PropertyCard
                key={prop.id}
                property={prop}
                onViewDetails={onViewDetails}
              />
            ))}
          </div>
        )}

      </div>
    </section>
  );
}
