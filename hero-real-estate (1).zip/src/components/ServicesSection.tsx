import { Home, Building2, Key, Landmark, Briefcase, FileSpreadsheet, ArrowUpRight } from 'lucide-react';
import { getWhatsAppUrl } from '../utils/format.ts';

export default function ServicesSection() {
  const services = [
    {
      icon: Home,
      title: 'House Rentals',
      description: 'Exclusive detached duplexes, semi-detached villas, and luxury terraces in premier residential estates across Nigeria with transparent tenancy agreements.',
      actionText: 'Explore Rental Homes'
    },
    {
      icon: Building2,
      title: 'Apartment Rentals',
      description: 'Fully furnished and serviced high-rise apartments, penthouses, and studios in prime business and diplomatic districts such as Victoria Island, Ikoyi, and Maitama.',
      actionText: 'Browse Apartments'
    },
    {
      icon: Key,
      title: 'Property Sales',
      description: 'Turnkey luxury acquisitions and residential investments. We facilitate direct purchases with clean legal title deeds and seamless title registration.',
      actionText: 'View Properties for Sale'
    },
    {
      icon: Landmark,
      title: 'Land Sales',
      description: 'Prime residential, commercial, and mixed-use land parcels in high-growth corridors (Epe, Lekki Free Trade Zone, Ibeju-Lekki, Abuja Industrial, Port Harcourt GRA).',
      actionText: 'Inquire on Land'
    },
    {
      icon: Briefcase,
      title: 'Property Management',
      description: 'End-to-end asset oversight for landlords and diaspora investors: tenant screening, rent collection, routine facility maintenance, and asset value appreciation.',
      actionText: 'Manage My Property'
    },
    {
      icon: FileSpreadsheet,
      title: 'Real Estate Consultancy',
      description: 'Feasibility studies, property valuation, market yield projections, and strategic advisory for developers, institutional funds, and private wealth clients.',
      actionText: 'Schedule Consultation'
    }
  ];

  return (
    <section id="services" className="py-24 bg-[#080808] border-t border-neutral-900 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#F5BD45] uppercase tracking-widest mb-3">
              <span>Comprehensive Solutions</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight">
              Our Professional Services
            </h2>
            <p className="mt-4 text-base text-neutral-400 max-w-xl">
              Serving property seekers, owners, and institutional investors throughout all 36 states of Nigeria.
            </p>
          </div>

          <a
            href={getWhatsAppUrl(undefined, 'Hello HERO REAL ESTATE, I would like to inquire about your real estate services in Nigeria.')}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#F5BD45] hover:text-white border-b border-[#F5BD45] pb-1 self-start md:self-end transition-colors cursor-pointer"
          >
            <span>Request Corporate Proposal</span>
            <ArrowUpRight className="w-4 h-4" />
          </a>
        </div>

        {/* 6 Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((srv, idx) => {
            const Icon = srv.icon;
            return (
              <div
                key={idx}
                className="bg-[#111111] border border-neutral-800 rounded-2xl p-7 hover:border-[#F5BD45]/50 transition-all duration-300 flex flex-col justify-between group"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-neutral-900 border border-neutral-800 group-hover:border-[#F5BD45]/40 flex items-center justify-center text-[#F5BD45] mb-5 transition-colors">
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3 group-hover:text-[#F5BD45] transition-colors">
                    {srv.title}
                  </h3>
                  <p className="text-sm text-neutral-400 leading-relaxed">
                    {srv.description}
                  </p>
                </div>

                <div className="mt-6 pt-5 border-t border-neutral-800/80">
                  <a
                    href={getWhatsAppUrl(undefined, `Hello HERO REAL ESTATE, I am inquiring about your ${srv.title} service.`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-neutral-300 group-hover:text-[#F5BD45] transition-colors"
                  >
                    <span>{srv.actionText}</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
