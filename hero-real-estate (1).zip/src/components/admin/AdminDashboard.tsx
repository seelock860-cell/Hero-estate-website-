import { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  Home,
  MessageSquare,
  Database,
  Lock,
  LogOut,
  Plus,
  Edit2,
  Trash2,
  Eye,
  EyeOff,
  CheckCircle,
  Clock,
  Phone,
  Mail,
  ExternalLink,
  ShieldAlert,
  ArrowLeft,
  Search,
  Filter
} from 'lucide-react';
import Logo from '../Logo.tsx';
import type { Property, CustomerEnquiry, DashboardStats } from '../../types.ts';
import { api, clearStoredToken } from '../../services/api.ts';
import { formatNaira, getWhatsAppUrl } from '../../utils/format.ts';
import SupabaseSettingsView from './SupabaseSettingsView.tsx';
import PropertyFormModal from './PropertyFormModal.tsx';
import ChangePasswordModal from './ChangePasswordModal.tsx';

interface AdminDashboardProps {
  onBackToSite: () => void;
  adminUser: { username: string; is_initial_password: boolean };
  onUpdateAdminUser: (user: { username: string; is_initial_password: boolean }) => void;
}

type TabType = 'overview' | 'properties' | 'enquiries' | 'supabase';

export default function AdminDashboard({ onBackToSite, adminUser, onUpdateAdminUser }: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [properties, setProperties] = useState<Property[]>([]);
  const [enquiries, setEnquiries] = useState<CustomerEnquiry[]>([]);
  const [loading, setLoading] = useState(true);

  // Property Modal State
  const [isPropertyModalOpen, setIsPropertyModalOpen] = useState(false);
  const [editingProperty, setEditingProperty] = useState<Property | null>(null);

  // Password Modal State
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);

  // Search in properties table
  const [propertySearch, setPropertySearch] = useState('');
  const [enquiryFilter, setEnquiryFilter] = useState<'all' | 'pending' | 'resolved'>('all');

  const loadData = async () => {
    setLoading(true);
    try {
      const [statsData, propsData, enqData] = await Promise.all([
        api.getDashboardStats(),
        api.getAdminProperties(),
        api.getAdminEnquiries()
      ]);
      setStats(statsData);
      setProperties(propsData);
      setEnquiries(enqData);
    } catch (err) {
      console.error('Failed to load admin data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleLogout = () => {
    clearStoredToken();
    onBackToSite();
  };

  // Property Actions
  const handleOpenAddProperty = () => {
    setEditingProperty(null);
    setIsPropertyModalOpen(true);
  };

  const handleOpenEditProperty = (prop: Property) => {
    setEditingProperty(prop);
    setIsPropertyModalOpen(true);
  };

  const handleSaveProperty = async (data: Omit<Property, 'id' | 'created_at' | 'updated_at'>) => {
    if (editingProperty) {
      await api.updateProperty(editingProperty.id, data);
    } else {
      await api.createProperty(data);
    }
    await loadData();
  };

  const handleDeleteProperty = async (id: string, title: string) => {
    if (confirm(`Are you sure you want to delete "${title}"? This cannot be undone.`)) {
      await api.deleteProperty(id);
      await loadData();
    }
  };

  const handleTogglePublish = async (prop: Property) => {
    await api.updateProperty(prop.id, { published: !prop.published });
    await loadData();
  };

  const handleUpdateStatus = async (prop: Property, status: Property['availability_status']) => {
    await api.updateProperty(prop.id, { availability_status: status });
    await loadData();
  };

  // Enquiry Actions
  const handleToggleEnquiryStatus = async (enquiry: CustomerEnquiry) => {
    const nextStatus = enquiry.status === 'pending' ? 'resolved' : 'pending';
    await api.updateEnquiryStatus(enquiry.id, nextStatus);
    await loadData();
  };

  const handleDeleteEnquiry = async (id: string) => {
    if (confirm('Delete this customer enquiry record?')) {
      await api.deleteEnquiry(id);
      await loadData();
    }
  };

  const filteredProperties = properties.filter(p =>
    p.title.toLowerCase().includes(propertySearch.toLowerCase()) ||
    p.city.toLowerCase().includes(propertySearch.toLowerCase()) ||
    p.state.toLowerCase().includes(propertySearch.toLowerCase())
  );

  const filteredEnquiries = enquiries.filter(e => {
    if (enquiryFilter === 'all') return true;
    return e.status === enquiryFilter;
  });

  return (
    <div className="min-h-screen bg-[#080808] text-white flex flex-col">
      
      {/* Top Admin Navbar */}
      <header className="bg-[#0e0e0e] border-b border-neutral-800 sticky top-0 z-40 px-4 sm:px-8 py-3.5 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Logo />
          <span className="hidden sm:inline-block text-xs font-semibold px-2 py-0.5 rounded bg-neutral-800 text-[#F5BD45] border border-[#F5BD45]/30">
            Staff Administrator Console
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsPasswordModalOpen(true)}
            className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-900 border border-neutral-800 hover:border-[#F5BD45]/40 text-xs text-neutral-300 hover:text-white transition-colors"
          >
            <Lock className="w-3.5 h-3.5 text-[#F5BD45]" />
            <span>Password Settings</span>
          </button>

          <button
            onClick={onBackToSite}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-xs text-neutral-200 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>View Public Website</span>
          </button>

          <button
            onClick={handleLogout}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-red-400 hover:bg-neutral-900 transition-colors"
            title="Log out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>


      {/* Main Container */}
      <div className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col gap-8">
        
        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-neutral-800 pb-3 overflow-x-auto">
          <button
            onClick={() => setActiveTab('overview')}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer shrink-0 ${
              activeTab === 'overview'
                ? 'bg-[#F5BD45] text-black shadow-md'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>Dashboard Overview</span>
          </button>

          <button
            onClick={() => setActiveTab('properties')}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer shrink-0 ${
              activeTab === 'properties'
                ? 'bg-[#F5BD45] text-black shadow-md'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
            }`}
          >
            <Home className="w-4 h-4" />
            <span>Property Listings ({properties.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('enquiries')}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer shrink-0 ${
              activeTab === 'enquiries'
                ? 'bg-[#F5BD45] text-black shadow-md'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>Customer Enquiries ({enquiries.filter(e => e.status === 'pending').length} New)</span>
          </button>

          <button
            onClick={() => setActiveTab('supabase')}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer shrink-0 ${
              activeTab === 'supabase'
                ? 'bg-[#F5BD45] text-black shadow-md'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>Supabase Settings</span>
          </button>
        </div>

        {/* ================= TAB 1: OVERVIEW ================= */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            
            {/* KPI Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              
              <div className="bg-[#111111] border border-neutral-800 rounded-2xl p-6">
                <span className="text-xs uppercase tracking-wider text-neutral-400 font-semibold block mb-1">
                  Total Properties
                </span>
                <span className="text-3xl font-extrabold text-white tabular-nums">
                  {stats?.total_properties || properties.length}
                </span>
                <span className="text-[11px] text-neutral-500 block mt-2">Active in database</span>
              </div>

              <div className="bg-[#111111] border border-neutral-800 rounded-2xl p-6">
                <span className="text-xs uppercase tracking-wider text-[#F5BD45] font-semibold block mb-1">
                  Available for Rent
                </span>
                <span className="text-3xl font-extrabold text-[#F5BD45] tabular-nums">
                  {stats?.properties_for_rent || properties.filter(p => p.listing_type === 'rent').length}
                </span>
                <span className="text-[11px] text-neutral-500 block mt-2">Houses & apartments</span>
              </div>

              <div className="bg-[#111111] border border-neutral-800 rounded-2xl p-6">
                <span className="text-xs uppercase tracking-wider text-neutral-400 font-semibold block mb-1">
                  Available for Sale
                </span>
                <span className="text-3xl font-extrabold text-white tabular-nums">
                  {stats?.properties_for_sale || properties.filter(p => p.listing_type === 'sale').length}
                </span>
                <span className="text-[11px] text-neutral-500 block mt-2">Luxury sales portfolio</span>
              </div>

              <div className="bg-[#111111] border border-neutral-800 rounded-2xl p-6">
                <span className="text-xs uppercase tracking-wider text-neutral-400 font-semibold block mb-1">
                  Customer Enquiries
                </span>
                <span className="text-3xl font-extrabold text-white tabular-nums">
                  {stats?.total_enquiries || enquiries.length}
                </span>
                <span className="text-[11px] text-emerald-400 block mt-2">
                  {enquiries.filter(e => e.status === 'pending').length} pending action
                </span>
              </div>

            </div>

            {/* Quick Actions & Recent Listings */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              
              {/* Left 2 Cols: Recently Added Properties */}
              <div className="lg:col-span-2 bg-[#111111] border border-neutral-800 rounded-2xl p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold text-white">Recently Added Properties</h3>
                  <button
                    onClick={() => setActiveTab('properties')}
                    className="text-xs text-[#F5BD45] hover:underline"
                  >
                    View All ({properties.length})
                  </button>
                </div>

                <div className="divide-y divide-neutral-800">
                  {properties.slice(0, 5).map(prop => (
                    <div key={prop.id} className="py-3 flex items-center justify-between gap-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={prop.image_urls[0]}
                          alt={prop.title}
                          className="w-12 h-10 object-cover rounded-lg border border-neutral-800"
                        />
                        <div>
                          <h4 className="text-xs sm:text-sm font-semibold text-white line-clamp-1">{prop.title}</h4>
                          <span className="text-[11px] text-neutral-400">{prop.city}, {prop.state} · For {prop.listing_type}</span>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <span className="text-xs font-bold text-[#F5BD45] block tabular-nums">
                          {formatNaira(prop.price)}
                        </span>
                        <span className={`text-[10px] font-semibold uppercase ${
                          prop.published ? 'text-emerald-400' : 'text-neutral-500'
                        }`}>
                          {prop.published ? 'Published' : 'Draft'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Right Col: Admin Quick Tools */}
              <div className="bg-[#111111] border border-neutral-800 rounded-2xl p-6 space-y-4 flex flex-col justify-between">
                <div>
                  <h3 className="text-base font-bold text-white mb-2">Administrator Tools</h3>
                  <p className="text-xs text-neutral-400 leading-relaxed mb-6">
                    Quickly add new Nigerian property listings, respond to prospective tenants via WhatsApp, or check Supabase cloud sync status.
                  </p>

                  <div className="space-y-3">
                    <button
                      onClick={handleOpenAddProperty}
                      className="w-full py-3 rounded-xl bg-[#F5BD45] hover:bg-[#e5ac33] text-black font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add New Property</span>
                    </button>

                    <button
                      onClick={() => setActiveTab('enquiries')}
                      className="w-full py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-200 text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
                    >
                      <MessageSquare className="w-4 h-4 text-[#F5BD45]" />
                      <span>Review Enquiries</span>
                    </button>

                    <button
                      onClick={() => setActiveTab('supabase')}
                      className="w-full py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-200 text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
                    >
                      <Database className="w-4 h-4 text-[#F5BD45]" />
                      <span>Supabase PostgreSQL</span>
                    </button>
                  </div>
                </div>

                <div className="pt-4 border-t border-neutral-800/80 text-[11px] text-neutral-400 flex items-center justify-between">
                  <span>Administrator Console</span>
                  <span className="inline-flex items-center gap-1.5 text-emerald-400 font-medium">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    Authenticated
                  </span>
                </div>
              </div>

            </div>

          </div>
        )}

        {/* ================= TAB 2: PROPERTIES MANAGEMENT ================= */}
        {activeTab === 'properties' && (
          <div className="space-y-6">
            
            {/* Header & Filter Controls */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="relative flex-1 max-w-md">
                <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Filter by title, city, or state..."
                  value={propertySearch}
                  onChange={(e) => setPropertySearch(e.target.value)}
                  className="w-full bg-[#111111] border border-neutral-700/80 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white focus:outline-none focus:border-[#F5BD45]"
                />
              </div>

              <button
                onClick={handleOpenAddProperty}
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-[#F5BD45] hover:bg-[#e5ac33] text-black font-extrabold text-xs uppercase tracking-wider transition-colors cursor-pointer shadow-lg shadow-[#F5BD45]/20 shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>Add Property Listing</span>
              </button>
            </div>

            {/* Properties Table */}
            <div className="bg-[#111111] border border-neutral-800 rounded-2xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-neutral-300">
                  <thead className="bg-[#0e0e0e] text-neutral-400 uppercase text-[11px] font-bold border-b border-neutral-800">
                    <tr>
                      <th className="px-6 py-4">Property</th>
                      <th className="px-6 py-4">Category</th>
                      <th className="px-6 py-4">Price (NGN)</th>
                      <th className="px-6 py-4">Location</th>
                      <th className="px-6 py-4">Specs</th>
                      <th className="px-6 py-4">Status</th>
                      <th className="px-6 py-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-800/80">
                    {filteredProperties.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="px-6 py-12 text-center text-neutral-500">
                          No properties found matching your filter.
                        </td>
                      </tr>
                    ) : (
                      filteredProperties.map(prop => (
                        <tr key={prop.id} className="hover:bg-neutral-900/40 transition-colors">
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-3">
                              <img
                                src={prop.image_urls[0]}
                                alt={prop.title}
                                className="w-12 h-10 object-cover rounded-lg border border-neutral-800 shrink-0"
                              />
                              <div>
                                <span className="font-bold text-white block line-clamp-1">{prop.title}</span>
                                <span className="text-[11px] text-neutral-500 uppercase font-semibold">For {prop.listing_type}</span>
                              </div>
                            </div>
                          </td>

                          <td className="px-6 py-4 capitalize">
                            <span className="px-2.5 py-1 rounded bg-neutral-900 border border-neutral-800 text-[11px]">
                              {prop.property_type}
                            </span>
                          </td>

                          <td className="px-6 py-4 font-bold text-[#F5BD45] tabular-nums whitespace-nowrap">
                            {formatNaira(prop.price, prop.listing_type === 'rent' ? prop.price_period : undefined)}
                          </td>

                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className="block font-medium text-white">{prop.city}</span>
                            <span className="text-[11px] text-neutral-500">{prop.state}</span>
                          </td>

                          <td className="px-6 py-4 whitespace-nowrap text-neutral-400">
                            {prop.bedrooms} Bed · {prop.bathrooms} Bath · {prop.parking_spaces} Park
                          </td>

                          <td className="px-6 py-4 whitespace-nowrap">
                            <select
                              value={prop.availability_status}
                              onChange={(e) => handleUpdateStatus(prop, e.target.value as Property['availability_status'])}
                              className="bg-[#181818] border border-neutral-700 text-neutral-200 text-xs rounded-lg px-2 py-1 focus:outline-none focus:border-[#F5BD45]"
                            >
                              <option value="available">Available</option>
                              <option value="rented">Rented</option>
                              <option value="sold">Sold</option>
                              <option value="unavailable">Unavailable</option>
                            </select>
                          </td>

                          <td className="px-6 py-4 text-right whitespace-nowrap">
                            <div className="flex items-center justify-end gap-2">
                              {/* Publish / Unpublish Toggle */}
                              <button
                                onClick={() => handleTogglePublish(prop)}
                                className={`p-1.5 rounded-lg border transition-colors ${
                                  prop.published
                                    ? 'bg-emerald-950/40 text-emerald-400 border-emerald-500/30 hover:bg-emerald-950/60'
                                    : 'bg-neutral-800 text-neutral-500 border-neutral-700 hover:text-white'
                                }`}
                                title={prop.published ? 'Published (Click to Unpublish)' : 'Draft (Click to Publish)'}
                              >
                                {prop.published ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                              </button>

                              {/* Edit */}
                              <button
                                onClick={() => handleOpenEditProperty(prop)}
                                className="p-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-800"
                                title="Edit details"
                              >
                                <Edit2 className="w-4 h-4" />
                              </button>

                              {/* Delete */}
                              <button
                                onClick={() => handleDeleteProperty(prop.id, prop.title)}
                                className="p-1.5 rounded-lg bg-neutral-900 hover:bg-red-950 text-neutral-400 hover:text-red-400 border border-neutral-800 hover:border-red-500/30"
                                title="Delete property"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* ================= TAB 3: CUSTOMER ENQUIRIES ================= */}
        {activeTab === 'enquiries' && (
          <div className="space-y-6">
            
            {/* Filter Tabs */}
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setEnquiryFilter('all')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                    enquiryFilter === 'all'
                      ? 'bg-[#F5BD45] text-black font-bold'
                      : 'bg-[#141414] text-neutral-400 hover:text-white border border-neutral-800'
                  }`}
                >
                  All Enquiries ({enquiries.length})
                </button>
                <button
                  onClick={() => setEnquiryFilter('pending')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                    enquiryFilter === 'pending'
                      ? 'bg-[#F5BD45] text-black font-bold'
                      : 'bg-[#141414] text-neutral-400 hover:text-white border border-neutral-800'
                  }`}
                >
                  Pending ({enquiries.filter(e => e.status === 'pending').length})
                </button>
                <button
                  onClick={() => setEnquiryFilter('resolved')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                    enquiryFilter === 'resolved'
                      ? 'bg-[#F5BD45] text-black font-bold'
                      : 'bg-[#141414] text-neutral-400 hover:text-white border border-neutral-800'
                  }`}
                >
                  Resolved ({enquiries.filter(e => e.status === 'resolved').length})
                </button>
              </div>

              <span className="text-xs text-neutral-400 hidden sm:inline">
                Click customer WhatsApp button to reply immediately.
              </span>
            </div>

            {/* Enquiries List */}
            {filteredEnquiries.length === 0 ? (
              <div className="bg-[#111111] border border-neutral-800 rounded-2xl p-12 text-center text-neutral-400">
                <p>No enquiries found in this category.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredEnquiries.map(enq => (
                  <div
                    key={enq.id}
                    className="bg-[#111111] border border-neutral-800 rounded-2xl p-6 transition-all hover:border-neutral-700 flex flex-col md:flex-row md:items-start justify-between gap-6"
                  >
                    <div className="space-y-2 flex-1">
                      <div className="flex flex-wrap items-center gap-3">
                        <h4 className="text-base font-bold text-white">{enq.customer_name}</h4>
                        <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider ${
                          enq.status === 'pending'
                            ? 'bg-amber-950/60 text-amber-400 border border-amber-500/30'
                            : 'bg-emerald-950/60 text-emerald-400 border border-emerald-500/30'
                        }`}>
                          {enq.status}
                        </span>
                        <span className="text-xs text-neutral-500">
                          {new Date(enq.created_at).toLocaleString()}
                        </span>
                      </div>

                      {enq.property_title && (
                        <div className="text-xs font-semibold text-[#F5BD45]">
                          Regarding Property: {enq.property_title}
                        </div>
                      )}

                      <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed bg-[#161616] p-3 rounded-xl border border-neutral-800/80 whitespace-pre-wrap">
                        {enq.message}
                      </p>

                      <div className="flex flex-wrap items-center gap-4 text-xs text-neutral-400 pt-1">
                        <span className="flex items-center gap-1.5">
                          <Phone className="w-3.5 h-3.5 text-[#F5BD45]" />
                          {enq.phone_number}
                        </span>
                        {enq.email && (
                          <span className="flex items-center gap-1.5">
                            <Mail className="w-3.5 h-3.5 text-[#F5BD45]" />
                            {enq.email}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Enquiry Actions */}
                    <div className="flex items-center md:flex-col gap-2 shrink-0">
                      {/* Contact on WhatsApp */}
                      <a
                        href={getWhatsAppUrl(
                          enq.phone_number,
                          `Hello ${enq.customer_name}, this is HERO REAL ESTATE regarding your property enquiry for "${enq.property_title || 'our listings'}".`
                        )}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 md:w-full px-4 py-2 bg-[#25D366] hover:bg-[#20ba5a] text-black font-bold text-xs uppercase tracking-wider rounded-xl transition-colors flex items-center justify-center gap-2"
                      >
                        <MessageSquare className="w-3.5 h-3.5 fill-current" />
                        <span>Reply on WhatsApp</span>
                      </a>

                      {/* Status Toggle */}
                      <button
                        onClick={() => handleToggleEnquiryStatus(enq)}
                        className={`flex-1 md:w-full px-4 py-2 text-xs font-semibold rounded-xl border transition-colors cursor-pointer ${
                          enq.status === 'pending'
                            ? 'bg-neutral-800 hover:bg-neutral-700 text-white border-neutral-700'
                            : 'bg-neutral-900 text-neutral-400 hover:text-white border-neutral-800'
                        }`}
                      >
                        Mark as {enq.status === 'pending' ? 'Resolved' : 'Pending'}
                      </button>

                      {/* Delete */}
                      <button
                        onClick={() => handleDeleteEnquiry(enq.id)}
                        className="p-2 text-neutral-500 hover:text-red-400 rounded-xl hover:bg-neutral-900 transition-colors"
                        title="Delete record"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                  </div>
                ))}
              </div>
            )}

          </div>
        )}

        {/* ================= TAB 4: SUPABASE SETTINGS ================= */}
        {activeTab === 'supabase' && (
          <SupabaseSettingsView />
        )}

      </div>

      {/* Property Form Modal */}
      <PropertyFormModal
        isOpen={isPropertyModalOpen}
        property={editingProperty}
        onClose={() => setIsPropertyModalOpen(false)}
        onSave={handleSaveProperty}
      />

      {/* Change Password Modal */}
      <ChangePasswordModal
        isOpen={isPasswordModalOpen}
        isInitialRequired={adminUser.is_initial_password}
        onClose={() => setIsPasswordModalOpen(false)}
        onSuccess={() => onUpdateAdminUser({ ...adminUser, is_initial_password: false })}
      />

    </div>
  );
}
