import { useState, useEffect, useRef } from 'react';
import { X, Plus, Trash2, Image, Sparkles, UploadCloud, FileUp, Loader2, CheckCircle, FileText } from 'lucide-react';
import type { Property, PropertyType, ListingType, AvailabilityStatus } from '../../types.ts';
import { IMAGES } from '../../assets/images.ts';
import { formatNaira } from '../../utils/format.ts';
import { api } from '../../services/api.ts';

interface PropertyFormModalProps {
  property?: Property | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Omit<Property, 'id' | 'created_at' | 'updated_at'>) => Promise<void>;
}

const PRESET_IMAGES = [
  { name: 'Sunset Luxury Mansion', url: IMAGES.heroMansion },
  { name: 'Lekki Contemporary Duplex', url: IMAGES.lekkiDuplex },
  { name: 'Victoria Island Penthouse/Apartment', url: IMAGES.viApartment },
  { name: 'Maitama Abuja Bungalow', url: IMAGES.abujaBungalow },
  { name: 'Lagos Waterfront Skyline', url: IMAGES.lagosSkyline },
];

const COMMON_AMENITIES = [
  '24/7 Electricity',
  'Armed Estate Security',
  'CCTV Surveillance',
  'Swimming Pool',
  'Fitted Kitchen',
  'Boys Quarters (BQ)',
  'Water Treatment Plant',
  'Fitness Gym',
  'Ocean / Waterfront View',
  'Elevator',
  'Private Boat Jetty',
  'Solar Power Backup',
  'Automated Gate',
  'Children Play Area'
];

export default function PropertyFormModal({ property, isOpen, onClose, onSave }: PropertyFormModalProps) {
  if (!isOpen) return null;

  const [title, setTitle] = useState(property?.title || '');
  const [description, setDescription] = useState(property?.description || '');
  const [propertyType, setPropertyType] = useState<PropertyType>(property?.property_type || 'duplex');
  const [listingType, setListingType] = useState<ListingType>(property?.listing_type || 'rent');
  const [price, setPrice] = useState<number>(property?.price || 2500000);
  const [pricePeriod, setPricePeriod] = useState<'year' | 'month' | 'outright'>(property?.price_period || 'year');
  const [state, setState] = useState(property?.state || 'Lagos');
  const [city, setCity] = useState(property?.city || 'Lekki Phase 1');
  const [address, setAddress] = useState(property?.address || '');
  const [bedrooms, setBedrooms] = useState<number>(property?.bedrooms || 4);
  const [bathrooms, setBathrooms] = useState<number>(property?.bathrooms || 4);
  const [parkingSpaces, setParkingSpaces] = useState<number>(property?.parking_spaces || 2);
  const [availabilityStatus, setAvailabilityStatus] = useState<AvailabilityStatus>(property?.availability_status || 'available');
  const [published, setPublished] = useState<boolean>(property?.published !== undefined ? property.published : true);
  const [featured, setFeatured] = useState<boolean>(property?.featured || false);
  const [imageUrls, setImageUrls] = useState<string[]>(
    property?.image_urls && property.image_urls.length > 0
      ? property.image_urls
      : [IMAGES.lekkiDuplex]
  );
  const [newImageUrl, setNewImageUrl] = useState('');
  const [amenities, setAmenities] = useState<string[]>(property?.amenities || [
    '24/7 Electricity',
    'Armed Estate Security',
    'Fitted Kitchen'
  ]);
  const [newAmenity, setNewAmenity] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // File Upload State
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFilesSelected = async (files: FileList | File[]) => {
    if (!files || files.length === 0) return;
    setIsUploading(true);
    setUploadProgress(`Uploading ${files.length} file${files.length > 1 ? 's' : ''}...`);

    const uploadedUrls: string[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      try {
        const url = await api.uploadFile(file);
        if (url) {
          uploadedUrls.push(url);
        }
      } catch (err) {
        console.error('Error uploading file:', file.name, err);
      }
    }

    if (uploadedUrls.length > 0) {
      setImageUrls(prev => [...prev, ...uploadedUrls]);
      setUploadProgress(`Successfully added ${uploadedUrls.length} file${uploadedUrls.length > 1 ? 's' : ''}!`);
      setTimeout(() => setUploadProgress(null), 3000);
    } else {
      setUploadProgress('No files could be processed.');
      setTimeout(() => setUploadProgress(null), 3000);
    }
    setIsUploading(false);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFilesSelected(e.dataTransfer.files);
    }
  };

  const handleAddPresetImage = (url: string) => {
    if (!imageUrls.includes(url)) {
      setImageUrls([...imageUrls, url]);
    }
  };

  const handleAddCustomImage = () => {
    if (newImageUrl.trim() && !imageUrls.includes(newImageUrl.trim())) {
      setImageUrls([...imageUrls, newImageUrl.trim()]);
      setNewImageUrl('');
    }
  };

  const handleRemoveImage = (index: number) => {
    setImageUrls(imageUrls.filter((_, i) => i !== index));
  };

  const toggleAmenity = (item: string) => {
    if (amenities.includes(item)) {
      setAmenities(amenities.filter(a => a !== item));
    } else {
      setAmenities([...amenities, item]);
    }
  };

  const handleAddCustomAmenity = () => {
    if (newAmenity.trim() && !amenities.includes(newAmenity.trim())) {
      setAmenities([...amenities, newAmenity.trim()]);
      setNewAmenity('');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !price || !state.trim() || !city.trim()) {
      setError('Title, price, state, and city are mandatory.');
      return;
    }

    setSaving(true);
    setError(null);
    try {
      await onSave({
        title: title.trim(),
        description: description.trim(),
        property_type: propertyType,
        listing_type: listingType,
        price: Number(price),
        price_period: listingType === 'rent' ? pricePeriod : 'outright',
        state: state.trim(),
        city: city.trim(),
        address: address.trim(),
        bedrooms: Number(bedrooms),
        bathrooms: Number(bathrooms),
        parking_spaces: Number(parkingSpaces),
        image_urls: imageUrls.length > 0 ? imageUrls : [IMAGES.lekkiDuplex],
        availability_status: availabilityStatus,
        published,
        featured,
        amenities
      });
      onClose();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to save property';
      setError(msg);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div 
        className="relative w-full max-w-3xl bg-[#111111] border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-[#0d0d0d] shrink-0">
          <div>
            <h2 className="text-lg font-bold text-white">
              {property ? 'Edit Property Listing' : 'Add New Property Listing'}
            </h2>
            <p className="text-xs text-neutral-400">
              Manage details, pricing in Naira (₦), photos, and publication status.
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form */}
        <form onSubmit={handleSubmit} className="overflow-y-auto p-6 space-y-6">
          {error && (
            <div className="p-3 bg-red-950/50 border border-red-500/50 rounded-xl text-xs text-red-300">
              {error}
            </div>
          )}

          {/* Title & Category */}
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                Property Title *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. 4 Bedroom Contemporary Duplex with BQ"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-[#181818] border border-neutral-700 focus:border-[#F5BD45] rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                  Category *
                </label>
                <select
                  value={propertyType}
                  onChange={(e) => setPropertyType(e.target.value as PropertyType)}
                  className="w-full bg-[#181818] border border-neutral-700 focus:border-[#F5BD45] rounded-xl px-3 py-2 text-sm text-white focus:outline-none"
                >
                  <option value="duplex">Duplex</option>
                  <option value="apartment">Apartment</option>
                  <option value="bungalow">Bungalow</option>
                  <option value="terrace">Terrace Duplex</option>
                  <option value="mansion">Mansion</option>
                  <option value="penthouse">Penthouse</option>
                  <option value="land">Land</option>
                  <option value="commercial">Commercial</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                  Listing Type *
                </label>
                <select
                  value={listingType}
                  onChange={(e) => setListingType(e.target.value as ListingType)}
                  className="w-full bg-[#181818] border border-neutral-700 focus:border-[#F5BD45] rounded-xl px-3 py-2 text-sm text-white focus:outline-none"
                >
                  <option value="rent">For Rent</option>
                  <option value="sale">For Sale</option>
                  <option value="lease">For Lease</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                  Availability Status *
                </label>
                <select
                  value={availabilityStatus}
                  onChange={(e) => setAvailabilityStatus(e.target.value as AvailabilityStatus)}
                  className="w-full bg-[#181818] border border-neutral-700 focus:border-[#F5BD45] rounded-xl px-3 py-2 text-sm text-white focus:outline-none"
                >
                  <option value="available">Available</option>
                  <option value="rented">Rented</option>
                  <option value="sold">Sold</option>
                  <option value="unavailable">Unavailable</option>
                </select>
              </div>
            </div>
          </div>

          {/* Price */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-[#141414] p-4 rounded-xl border border-neutral-800">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#F5BD45] mb-1.5">
                Price in Nigerian Naira (₦) *
              </label>
              <input
                type="number"
                min="0"
                step="1000"
                required
                value={price}
                onChange={(e) => setPrice(Number(e.target.value))}
                className="w-full bg-[#1c1c1c] border border-neutral-700 focus:border-[#F5BD45] rounded-xl px-4 py-2.5 text-base font-bold text-white focus:outline-none tabular-nums"
              />
              <span className="block text-xs text-neutral-400 mt-1">
                Preview: {formatNaira(price, listingType === 'rent' ? pricePeriod : undefined)}
              </span>
            </div>

            {listingType === 'rent' && (
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                  Billing Period
                </label>
                <select
                  value={pricePeriod}
                  onChange={(e) => setPricePeriod(e.target.value as 'year' | 'month' | 'outright')}
                  className="w-full bg-[#1c1c1c] border border-neutral-700 focus:border-[#F5BD45] rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none"
                >
                  <option value="year">Per Year (/year)</option>
                  <option value="month">Per Month (/month)</option>
                  <option value="outright">One-time payment</option>
                </select>
              </div>
            )}
          </div>

          {/* Location & Address */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                State (Nigeria) *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Lagos"
                value={state}
                onChange={(e) => setState(e.target.value)}
                className="w-full bg-[#181818] border border-neutral-700 focus:border-[#F5BD45] rounded-xl px-3 py-2 text-sm text-white focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                City / District *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Lekki Phase 1"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full bg-[#181818] border border-neutral-700 focus:border-[#F5BD45] rounded-xl px-3 py-2 text-sm text-white focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                Full Street Address
              </label>
              <input
                type="text"
                placeholder="e.g. Admiralty Way, Lekki"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full bg-[#181818] border border-neutral-700 focus:border-[#F5BD45] rounded-xl px-3 py-2 text-sm text-white focus:outline-none"
              />
            </div>
          </div>

          {/* Specs: Beds, Baths, Parking */}
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                Bedrooms
              </label>
              <input
                type="number"
                min="0"
                max="20"
                value={bedrooms}
                onChange={(e) => setBedrooms(Number(e.target.value))}
                className="w-full bg-[#181818] border border-neutral-700 focus:border-[#F5BD45] rounded-xl px-3 py-2 text-sm text-white focus:outline-none tabular-nums"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                Bathrooms
              </label>
              <input
                type="number"
                min="0"
                max="20"
                value={bathrooms}
                onChange={(e) => setBathrooms(Number(e.target.value))}
                className="w-full bg-[#181818] border border-neutral-700 focus:border-[#F5BD45] rounded-xl px-3 py-2 text-sm text-white focus:outline-none tabular-nums"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                Parking Spaces
              </label>
              <input
                type="number"
                min="0"
                max="50"
                value={parkingSpaces}
                onChange={(e) => setParkingSpaces(Number(e.target.value))}
                className="w-full bg-[#181818] border border-neutral-700 focus:border-[#F5BD45] rounded-xl px-3 py-2 text-sm text-white focus:outline-none tabular-nums"
              />
            </div>
          </div>

          {/* Photographs & File Uploads Section */}
          <div className="space-y-4 bg-[#141414] border border-neutral-800 rounded-2xl p-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-800 pb-3">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#F5BD45]">
                  Property Files & Photographs Upload
                </label>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Upload photos, floor plans, brochures, or deed copies directly from your computer or phone.
                </p>
              </div>
              <span className="text-xs font-semibold text-neutral-300 px-3 py-1 bg-neutral-900 border border-neutral-800 rounded-lg self-start sm:self-auto">
                {imageUrls.length} file{imageUrls.length !== 1 ? 's' : ''} attached
              </span>
            </div>

            {/* Drag & Drop File Upload Box */}
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all duration-200 flex flex-col items-center justify-center gap-3 ${
                isDragging
                  ? 'border-[#F5BD45] bg-[#F5BD45]/10'
                  : 'border-neutral-700 hover:border-[#F5BD45]/60 bg-[#181818] hover:bg-[#1b1b1b]'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept="image/*,.pdf,.doc,.docx"
                onChange={(e) => {
                  if (e.target.files) handleFilesSelected(e.target.files);
                  e.target.value = '';
                }}
                className="hidden"
              />

              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#1C1608] to-[#0D0B05] border border-[#F5BD45]/40 flex items-center justify-center text-[#F5BD45] shadow-lg shadow-[#F5BD45]/10">
                {isUploading ? (
                  <Loader2 className="w-6 h-6 animate-spin" />
                ) : (
                  <UploadCloud className="w-6 h-6" />
                )}
              </div>

              <div>
                <p className="text-sm font-bold text-white">
                  {isUploading ? 'Processing & uploading your files...' : 'Click to upload files from your device, or drag and drop here'}
                </p>
                <p className="text-xs text-neutral-400 mt-1">
                  Upload any JPG, PNG, WEBP photos or PDF files directly from your computer, iPhone, or Android device.
                </p>
              </div>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  fileInputRef.current?.click();
                }}
                className="px-4 py-2 bg-neutral-800 hover:bg-[#F5BD45] hover:text-black text-white text-xs font-bold uppercase tracking-wider rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-md"
              >
                <FileUp className="w-4 h-4" />
                <span>Browse Files on Device</span>
              </button>
            </div>

            {/* Upload Status / Progress Message */}
            {uploadProgress && (
              <div className="p-3 bg-neutral-900 border border-[#F5BD45]/30 rounded-xl text-xs text-[#F5BD45] flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{uploadProgress}</span>
              </div>
            )}

            {/* Attached Photos & Files Preview Grid */}
            {imageUrls.length > 0 && (
              <div className="space-y-2 pt-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-400 block">
                  Attached Property Files ({imageUrls.length}):
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {imageUrls.map((url, idx) => (
                    <div key={idx} className="relative aspect-[4/3] rounded-xl overflow-hidden border border-neutral-700 bg-neutral-900 group shadow-md">
                      <img
                        src={url}
                        alt={`Property file ${idx + 1}`}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                        referrerPolicy="no-referrer"
                      />
                      {idx === 0 && (
                        <span className="absolute bottom-2 left-2 px-2 py-0.5 rounded bg-black/80 text-[#F5BD45] text-[10px] font-bold uppercase tracking-wider border border-[#F5BD45]/40">
                          Primary Photo
                        </span>
                      )}
                      <button
                        type="button"
                        onClick={() => handleRemoveImage(idx)}
                        className="absolute top-2 right-2 p-1.5 bg-black/85 hover:bg-red-600 text-white rounded-lg transition-colors shadow-md"
                        title="Remove file"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Secondary Option: Preset Library & URL Paste */}
            <div className="pt-3 border-t border-neutral-800/80 space-y-3">
              <div className="p-3 bg-[#181818] border border-neutral-800 rounded-xl space-y-2">
                <span className="text-[11px] text-neutral-400 font-medium block">
                  Or add from Nigerian Luxury Photo Library:
                </span>
                <div className="flex flex-wrap gap-2">
                  {PRESET_IMAGES.map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleAddPresetImage(preset.url)}
                      className="px-2.5 py-1 text-xs bg-neutral-800 hover:bg-[#F5BD45] hover:text-black text-neutral-200 rounded-md transition-colors"
                    >
                      + {preset.name}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Or paste an external web URL..."
                  value={newImageUrl}
                  onChange={(e) => setNewImageUrl(e.target.value)}
                  className="flex-1 bg-[#181818] border border-neutral-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#F5BD45]"
                />
                <button
                  type="button"
                  onClick={handleAddCustomImage}
                  className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-xs text-white rounded-xl font-semibold shrink-0"
                >
                  Add URL
                </button>
              </div>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
              Property Description *
            </label>
            <textarea
              rows={4}
              required
              placeholder="Provide a detailed description of architectural finishes, neighborhood security, power supply, and nearby landmarks..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-[#181818] border border-neutral-700 focus:border-[#F5BD45] rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none"
            />
          </div>

          {/* Amenities Tag Selector */}
          <div className="space-y-3">
            <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300">
              Amenities & Estate Infrastructure
            </label>
            <div className="flex flex-wrap gap-1.5">
              {COMMON_AMENITIES.map((item, idx) => {
                const active = amenities.includes(item);
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => toggleAmenity(item)}
                    className={`px-3 py-1 rounded-lg text-xs font-medium transition-all ${
                      active
                        ? 'bg-[#F5BD45] text-black font-semibold'
                        : 'bg-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    {active ? '✓ ' : '+ '} {item}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Publication and Featured Flags */}
          <div className="flex flex-wrap items-center gap-6 p-4 rounded-xl bg-[#141414] border border-neutral-800">
            <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-neutral-200">
              <input
                type="checkbox"
                checked={published}
                onChange={(e) => setPublished(e.target.checked)}
                className="w-4 h-4 accent-[#F5BD45] rounded"
              />
              <span>Published (Visible to public visitors)</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-neutral-200">
              <input
                type="checkbox"
                checked={featured}
                onChange={(e) => setFeatured(e.target.checked)}
                className="w-4 h-4 accent-[#F5BD45] rounded"
              />
              <span>Feature on Homepage Spotlight</span>
            </label>
          </div>

          {/* Form Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-neutral-800">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-bold uppercase tracking-wider transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-7 py-2.5 rounded-xl bg-[#F5BD45] hover:bg-[#e5ac33] text-black text-xs font-extrabold uppercase tracking-wider transition-colors shadow-lg shadow-[#F5BD45]/20 disabled:opacity-50"
            >
              {saving ? 'Saving Listing...' : property ? 'Update Property' : 'Publish Property'}
            </button>
          </div>
        </form>

      </div>
    </div>
  );
}
