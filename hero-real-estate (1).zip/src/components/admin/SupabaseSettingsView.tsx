import { useState, useEffect } from 'react';
import {
  Database,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Copy,
  Check,
  ExternalLink,
  ShieldCheck,
  KeyRound,
  ArrowUpRight,
  UploadCloud,
  DownloadCloud,
  HelpCircle
} from 'lucide-react';
import { api } from '../../services/api.ts';
import type { SupabaseConfig } from '../../types.ts';

const SUPABASE_SCHEMA_SQL = `-- HERO REAL ESTATE: Supabase PostgreSQL Schema & Security Rules

-- 1. Enable UUID Extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. Properties Table
CREATE TABLE IF NOT EXISTS public.properties (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    property_type TEXT NOT NULL,
    listing_type TEXT NOT NULL,
    price NUMERIC NOT NULL,
    price_period TEXT DEFAULT 'year',
    state TEXT NOT NULL,
    city TEXT NOT NULL,
    address TEXT NOT NULL,
    bedrooms INTEGER NOT NULL DEFAULT 1,
    bathrooms INTEGER NOT NULL DEFAULT 1,
    parking_spaces INTEGER NOT NULL DEFAULT 1,
    image_urls JSONB DEFAULT '[]'::jsonb,
    availability_status TEXT NOT NULL DEFAULT 'available',
    published BOOLEAN NOT NULL DEFAULT true,
    featured BOOLEAN NOT NULL DEFAULT false,
    amenities JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 3. Customer Enquiries Table
CREATE TABLE IF NOT EXISTS public.customer_enquiries (
    id TEXT PRIMARY KEY,
    customer_name TEXT NOT NULL,
    phone_number TEXT NOT NULL,
    email TEXT,
    message TEXT NOT NULL,
    property_id TEXT,
    property_title TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 4. Enable Row Level Security (RLS)
ALTER TABLE public.properties ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customer_enquiries ENABLE ROW LEVEL SECURITY;

-- 5. Drop existing policies to allow clean re-runs without duplicate policy errors
DROP POLICY IF EXISTS "Public can view published properties" ON public.properties;
DROP POLICY IF EXISTS "Allow anon read and write on properties" ON public.properties;
DROP POLICY IF EXISTS "Allow anon read and write on customer_enquiries" ON public.customer_enquiries;

-- 6. Apply Clean Permissive RLS Policies
CREATE POLICY "Public can view published properties" 
    ON public.properties FOR SELECT 
    USING (true);

CREATE POLICY "Allow anon read and write on properties" 
    ON public.properties FOR ALL 
    USING (true)
    WITH CHECK (true);

CREATE POLICY "Allow anon read and write on customer_enquiries" 
    ON public.customer_enquiries FOR ALL 
    USING (true)
    WITH CHECK (true);

-- 7. Storage: Create bucket for property photographs (Optional, safe execution)
DO $$
BEGIN
  INSERT INTO storage.buckets (id, name, public) 
  VALUES ('property-images', 'property-images', true)
  ON CONFLICT (id) DO NOTHING;
EXCEPTION WHEN OTHERS THEN
  NULL;
END $$;
`;

export default function SupabaseSettingsView() {
  const [config, setConfig] = useState<SupabaseConfig>({
    project_url: '',
    publishable_key: '',
    status: 'unconfigured'
  });
  const [urlInput, setUrlInput] = useState('');
  const [keyInput, setKeyInput] = useState('');
  const [testing, setTesting] = useState(false);
  const [saving, setSaving] = useState(false);
  const [pushing, setPushing] = useState(false);
  const [pulling, setPulling] = useState(false);
  const [testResult, setTestResult] = useState<{
    success: boolean;
    message: string;
    cleanedUrl?: string;
    cleanedKey?: string;
    tableExists?: boolean;
    tableCount?: number;
    warnings?: string[];
  } | null>(null);
  const [syncFeedback, setSyncFeedback] = useState<{ success: boolean; message: string } | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    loadConfig();
  }, []);

  const loadConfig = async () => {
    try {
      const cfg = await api.getSupabaseConfig();
      setConfig(cfg);
      setUrlInput(cfg.project_url || '');
      setKeyInput(cfg.publishable_key || '');
    } catch (err) {
      console.error('Failed to load config:', err);
    }
  };

  const handleTestConnection = async () => {
    setTesting(true);
    setTestResult(null);
    setSyncFeedback(null);
    try {
      const res = await api.testSupabaseConnection(urlInput, keyInput);
      setTestResult(res);
      if (res.cleanedUrl && res.cleanedUrl !== urlInput) {
        setUrlInput(res.cleanedUrl);
      }
      if (res.cleanedKey && res.cleanedKey !== keyInput) {
        setKeyInput(res.cleanedKey);
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Connection test failed';
      setTestResult({ success: false, message: msg });
    } finally {
      setTesting(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSyncFeedback(null);
    try {
      const res = await api.saveSupabaseConfig(urlInput, keyInput);
      setConfig(res.config);
      setTestResult(res.testResult);
      if (res.testResult.cleanedUrl) {
        setUrlInput(res.testResult.cleanedUrl);
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to save configuration';
      setTestResult({ success: false, message: msg });
    } finally {
      setSaving(false);
    }
  };

  const handlePushProperties = async () => {
    setPushing(true);
    setSyncFeedback(null);
    try {
      // If config not saved yet or inputs differ, save & test first!
      if (urlInput.trim() && keyInput.trim() && (urlInput.trim() !== config.project_url || keyInput.trim() !== config.publishable_key || config.status !== 'connected')) {
        const saveRes = await api.saveSupabaseConfig(urlInput.trim(), keyInput.trim());
        setConfig(saveRes.config);
        setTestResult(saveRes.testResult);
        if (!saveRes.testResult.success) {
          setSyncFeedback({ success: false, message: saveRes.testResult.message });
          setPushing(false);
          return;
        }
      }
      const res = await api.pushPropertiesToSupabase();
      setSyncFeedback(res);
      await loadConfig();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to push properties';
      setSyncFeedback({ success: false, message: msg });
    } finally {
      setPushing(false);
    }
  };

  const handlePullProperties = async () => {
    setPulling(true);
    setSyncFeedback(null);
    try {
      if (urlInput.trim() && keyInput.trim() && (urlInput.trim() !== config.project_url || keyInput.trim() !== config.publishable_key || config.status !== 'connected')) {
        const saveRes = await api.saveSupabaseConfig(urlInput.trim(), keyInput.trim());
        setConfig(saveRes.config);
      }
      const res = await api.pullPropertiesFromSupabase();
      setSyncFeedback(res);
      await loadConfig();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to pull properties';
      setSyncFeedback({ success: false, message: msg });
    } finally {
      setPulling(false);
    }
  };

  const copySqlToClipboard = () => {
    navigator.clipboard.writeText(SUPABASE_SCHEMA_SQL);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="space-y-8">
      
      {/* Top Banner & Status Header */}
      <div className="bg-[#111111] border border-neutral-800 rounded-2xl p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-800 pb-6 mb-6">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#1C1608] to-[#0D0B05] border border-[#F5BD45]/40 text-[#F5BD45]">
              <Database className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-white">Supabase Connection Settings</h2>
              <p className="text-xs sm:text-sm text-neutral-400">
                Connect HERO REAL ESTATE to your Supabase PostgreSQL cloud database for persistent listings and customer enquiries.
              </p>
            </div>
          </div>

          {/* Current Status Badge */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-neutral-400">Status:</span>
            {config.status === 'connected' ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-950/70 text-emerald-400 border border-emerald-500/40">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Supabase Connected
              </span>
            ) : config.status === 'error' ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-red-950/70 text-red-400 border border-red-500/40">
                <AlertCircle className="w-3.5 h-3.5" />
                Connection Error
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-neutral-800 text-neutral-300 border border-neutral-700">
                Local Database Active
              </span>
            )}
          </div>
        </div>

        {/* Quick Setup Instructions Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="p-4 rounded-xl bg-[#161616] border border-neutral-800/80">
            <div className="text-[#F5BD45] font-bold text-xs uppercase tracking-wider mb-1">
              Step 1: Get API Keys
            </div>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Open <a href="https://supabase.com/dashboard" target="_blank" rel="noopener noreferrer" className="text-white underline hover:text-[#F5BD45]">supabase.com</a> &gt; Your Project &gt; <strong>Project Settings</strong> (gear icon) &gt; <strong>API</strong>.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#161616] border border-neutral-800/80">
            <div className="text-[#F5BD45] font-bold text-xs uppercase tracking-wider mb-1">
              Step 2: Enter URL & Key
            </div>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Paste the <strong>Project URL</strong> (e.g. <code className="text-neutral-300">https://xyz.supabase.co</code>) and public <strong>anon key</strong> into the form below.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#161616] border border-neutral-800/80">
            <div className="text-[#F5BD45] font-bold text-xs uppercase tracking-wider mb-1">
              Step 3: Run SQL & Push
            </div>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Copy the ready-to-run SQL schema script below, run it in Supabase <strong>SQL Editor</strong>, then click <strong>"Push Properties"</strong>.
            </p>
          </div>
        </div>

        {/* Credentials Form */}
        <form onSubmit={handleSave} className="space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-2">
                Supabase Project URL
              </label>
              <input
                type="text"
                required
                placeholder="https://xyzcompany.supabase.co"
                value={urlInput}
                onChange={(e) => setUrlInput(e.target.value)}
                className="w-full bg-[#181818] border border-neutral-700 focus:border-[#F5BD45] rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none"
              />
              <span className="block text-[11px] text-neutral-400 mt-1">
                From Supabase Dashboard &gt; Project Settings &gt; API &gt; Project URL. (Format: <code className="text-neutral-300">https://[project-id].supabase.co</code>)
              </span>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-2">
                Supabase Publishable Key / Anon Public Key
              </label>
              <input
                type="text"
                required
                placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                value={keyInput}
                onChange={(e) => setKeyInput(e.target.value)}
                className="w-full bg-[#181818] border border-neutral-700 focus:border-[#F5BD45] rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none font-mono text-xs"
              />
              <span className="block text-[11px] text-neutral-400 mt-1">
                Your public <code className="text-neutral-300">anon</code> key (usually starts with <code className="text-neutral-300">eyJ...</code>).
              </span>
            </div>
          </div>

          {/* Test / Save Feedback Box */}
          {testResult && (
            <div className={`p-4 rounded-xl text-xs space-y-2 ${
              testResult.success
                ? 'bg-emerald-950/40 border border-emerald-500/40 text-emerald-300'
                : 'bg-red-950/40 border border-red-500/40 text-red-300'
            }`}>
              <div className="flex items-start gap-2.5">
                {testResult.success ? (
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-400 mt-0.5" />
                )}
                <div>
                  <p className="font-bold text-sm">
                    {testResult.success ? 'Supabase Connection Verified!' : 'Connection Check Failed'}
                  </p>
                  <p className="mt-1 leading-relaxed">{testResult.message}</p>
                </div>
              </div>

              {/* Table creation notice if table not created yet */}
              {testResult.success && testResult.tableExists === false && (
                <div className="p-3 bg-amber-950/60 border border-amber-500/40 rounded-lg text-amber-200 mt-2">
                  <span className="font-bold block mb-1">Action Required: Tables Not Initialized Yet</span>
                  <span>
                    Your Supabase credentials are valid, but the database tables do not exist yet. Please copy the <strong>SQL Script</strong> below, paste it into your Supabase SQL Editor and click <strong>RUN</strong>, then click <strong>"Push All Properties to Supabase"</strong>!
                  </span>
                </div>
              )}

              {testResult.warnings && testResult.warnings.length > 0 && (
                <ul className="list-disc pl-5 text-[11px] text-amber-300 space-y-1 pt-1">
                  {testResult.warnings.map((w, idx) => (
                    <li key={idx}>{w}</li>
                  ))}
                </ul>
              )}
            </div>
          )}

          {/* Sync Feedback Message */}
          {syncFeedback && (
            <div className={`p-4 rounded-xl text-xs flex items-center gap-2 ${
              syncFeedback.success
                ? 'bg-emerald-950/50 border border-emerald-500/50 text-emerald-200'
                : 'bg-red-950/50 border border-red-500/50 text-red-200'
            }`}>
              {syncFeedback.success ? <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" /> : <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />}
              <span>{syncFeedback.message}</span>
            </div>
          )}

          {/* Form Actions */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              type="button"
              onClick={handleTestConnection}
              disabled={testing || !urlInput.trim() || !keyInput.trim()}
              className="px-5 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-semibold text-xs uppercase tracking-wider transition-colors flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${testing ? 'animate-spin' : ''}`} />
              <span>{testing ? 'Testing...' : 'Test Connection'}</span>
            </button>

            <button
              type="submit"
              disabled={saving || !urlInput.trim() || !keyInput.trim()}
              className="px-6 py-2.5 rounded-xl bg-[#F5BD45] hover:bg-[#e5ac33] text-black font-extrabold text-xs uppercase tracking-wider transition-colors cursor-pointer shadow-lg shadow-[#F5BD45]/20 disabled:opacity-50"
            >
              <span>{saving ? 'Saving...' : 'Save Configuration'}</span>
            </button>

            {/* Direct Sync / Push Button */}
            <button
              type="button"
              onClick={handlePushProperties}
              disabled={pushing || !urlInput.trim() || !keyInput.trim()}
              className="px-5 py-2.5 rounded-xl bg-emerald-900/80 hover:bg-emerald-800 text-emerald-200 border border-emerald-600/50 font-bold text-xs uppercase tracking-wider transition-colors flex items-center gap-2 cursor-pointer disabled:opacity-50"
              title="Push current local Nigerian properties to Supabase"
            >
              <UploadCloud className="w-4 h-4 text-emerald-400" />
              <span>{pushing ? 'Syncing to Supabase...' : 'Push Properties to Supabase'}</span>
            </button>

            <button
              type="button"
              onClick={handlePullProperties}
              disabled={pulling || !urlInput.trim() || !keyInput.trim()}
              className="px-4 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border border-neutral-800 font-semibold text-xs uppercase tracking-wider transition-colors flex items-center gap-2 cursor-pointer disabled:opacity-50"
              title="Pull properties from Supabase into local cache"
            >
              <DownloadCloud className="w-4 h-4 text-[#F5BD45]" />
              <span>{pulling ? 'Pulling...' : 'Pull from Supabase'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* SQL Script & Guidance Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Step-by-Step SQL Guide */}
        <div className="lg:col-span-1 bg-[#111111] border border-neutral-800 rounded-2xl p-6 space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#F5BD45]" />
            Setup Checklist for Supabase
          </h3>

          <ol className="space-y-3 text-xs text-neutral-300 list-decimal pl-4 leading-relaxed">
            <li>
              <strong>Create a free project</strong> at{' '}
              <a href="https://supabase.com/dashboard" target="_blank" rel="noopener noreferrer" className="text-[#F5BD45] hover:underline">
                supabase.com
              </a>.
            </li>
            <li>
              In Supabase left sidebar, click <strong>SQL Editor</strong>.
            </li>
            <li>
              Click <strong>"New query"</strong>, paste the SQL schema script shown on the right, and click <strong>RUN</strong>.
            </li>
            <li>
              Go to <strong>Project Settings &gt; API</strong>, copy the <strong>Project URL</strong> and <strong>anon key</strong>.
            </li>
            <li>
              Paste them above, click <strong>"Test Connection"</strong>, then <strong>"Save Configuration"</strong>.
            </li>
            <li>
              Click <strong>"Push Properties to Supabase"</strong> to seed your Supabase database with all existing Nigerian properties!
            </li>
          </ol>

          <div className="pt-2 border-t border-neutral-800">
            <a
              href="https://supabase.com/dashboard"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-xs text-[#F5BD45] font-semibold hover:underline"
            >
              <span>Open Supabase Dashboard</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Ready-to-Run SQL Script Box */}
        <div className="lg:col-span-2 bg-[#111111] border border-neutral-800 rounded-2xl p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-[#F5BD45]" />
                <h3 className="text-base font-bold text-white">Idempotent Supabase SQL Schema</h3>
              </div>

              <button
                type="button"
                onClick={copySqlToClipboard}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs text-neutral-200 transition-colors cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied to Clipboard!' : 'Copy SQL Script'}</span>
              </button>
            </div>

            <p className="text-xs text-neutral-400 mb-3">
              This script creates the <code className="text-white">properties</code> and <code className="text-white">customer_enquiries</code> tables and applies Row Level Security (RLS) policies and storage:
            </p>

            <pre className="bg-[#0a0a0a] border border-neutral-800 rounded-xl p-4 text-[11px] font-mono text-neutral-300 overflow-x-auto max-h-64 leading-relaxed select-all">
              {SUPABASE_SCHEMA_SQL}
            </pre>
          </div>

          <div className="mt-4 pt-3 border-t border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-neutral-400">
            <span>Safe to re-run multiple times (drops duplicate policies automatically)</span>
            <button
              onClick={copySqlToClipboard}
              className="text-[#F5BD45] font-semibold hover:underline self-start sm:self-auto cursor-pointer"
            >
              {copied ? '✓ Script Copied!' : 'Click here to Copy Script'}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
