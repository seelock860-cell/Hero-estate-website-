import type { Property, CustomerEnquiry, SupabaseConfig, DashboardStats } from '../types.ts';

const TOKEN_KEY = 'hero_admin_token';
const ADMIN_USER_KEY = 'hero_admin_user';

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setStoredToken(token: string, user: { username: string; is_initial_password: boolean }) {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(ADMIN_USER_KEY, JSON.stringify(user));
}

export function clearStoredToken() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(ADMIN_USER_KEY);
}

export function getStoredAdminUser(): { username: string; is_initial_password: boolean } | null {
  try {
    const raw = localStorage.getItem(ADMIN_USER_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function getAuthHeaders(): HeadersInit {
  const token = getStoredToken();
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {})
  };
}

export const api = {
  // Public
  async getProperties(filters?: {
    state?: string;
    city?: string;
    property_type?: string;
    listing_type?: string;
    min_price?: number;
    max_price?: number;
    query?: string;
  }): Promise<Property[]> {
    const params = new URLSearchParams();
    if (filters?.state && filters.state !== 'all') params.set('state', filters.state);
    if (filters?.city && filters.city !== 'all') params.set('city', filters.city);
    if (filters?.property_type && filters.property_type !== 'all') params.set('property_type', filters.property_type);
    if (filters?.listing_type && filters.listing_type !== 'all') params.set('listing_type', filters.listing_type);
    if (filters?.min_price) params.set('min_price', filters.min_price.toString());
    if (filters?.max_price) params.set('max_price', filters.max_price.toString());
    if (filters?.query) params.set('query', filters.query);

    const res = await fetch(`/api/properties?${params.toString()}`);
    if (!res.ok) throw new Error('Failed to fetch properties');
    const data = await res.json();
    return data.properties;
  },

  async getPropertyById(id: string): Promise<Property> {
    const res = await fetch(`/api/properties/${id}`);
    if (!res.ok) throw new Error('Property not found');
    const data = await res.json();
    return data.property;
  },

  async submitEnquiry(enquiry: {
    customer_name: string;
    phone_number: string;
    email: string;
    message: string;
    property_id?: string;
    property_title?: string;
  }): Promise<CustomerEnquiry> {
    const res = await fetch('/api/enquiries', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(enquiry)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to submit enquiry');
    return data.enquiry;
  },

  // Auth
  async login(username: string, password: string): Promise<{ token: string; username: string; is_initial_password: boolean }> {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Login failed');
    setStoredToken(data.token, { username: data.username, is_initial_password: data.is_initial_password });
    return data;
  },

  async verifyAuth(): Promise<boolean> {
    const token = getStoredToken();
    if (!token) return false;
    try {
      const res = await fetch('/api/auth/verify', {
        headers: getAuthHeaders()
      });
      return res.ok;
    } catch {
      return false;
    }
  },

  async changePassword(new_password: string): Promise<void> {
    const res = await fetch('/api/auth/change-password', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ new_password })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to change password');
    const user = getStoredAdminUser();
    if (user) {
      setStoredToken(getStoredToken() || '', { ...user, is_initial_password: false });
    }
  },

  // Admin Stats
  async getDashboardStats(): Promise<DashboardStats> {
    const res = await fetch('/api/admin/stats', { headers: getAuthHeaders() });
    if (!res.ok) throw new Error('Failed to fetch stats');
    const data = await res.json();
    return data.stats;
  },

  // Admin Properties
  async getAdminProperties(): Promise<Property[]> {
    const res = await fetch('/api/admin/properties', { headers: getAuthHeaders() });
    if (!res.ok) throw new Error('Failed to fetch admin properties');
    const data = await res.json();
    return data.properties;
  },

  async createProperty(property: Omit<Property, 'id' | 'created_at' | 'updated_at'>): Promise<Property> {
    const res = await fetch('/api/admin/properties', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(property)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to create property');
    return data.property;
  },

  async updateProperty(id: string, updates: Partial<Property>): Promise<Property> {
    const res = await fetch(`/api/admin/properties/${id}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(updates)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update property');
    return data.property;
  },

  async deleteProperty(id: string): Promise<void> {
    const res = await fetch(`/api/admin/properties/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders()
    });
    if (!res.ok) throw new Error('Failed to delete property');
  },

  async uploadFile(file: File): Promise<string> {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64Data = reader.result as string;
        try {
          const res = await fetch('/api/admin/upload', {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify({
              name: file.name,
              data: base64Data,
              type: file.type
            })
          });
          const json = await res.json();
          if (json.url) {
            resolve(json.url);
          } else {
            resolve(base64Data);
          }
        } catch {
          // Fallback to data URL
          resolve(base64Data);
        }
      };
      reader.onerror = () => {
        resolve('');
      };
      reader.readAsDataURL(file);
    });
  },

  // Admin Enquiries
  async getAdminEnquiries(): Promise<CustomerEnquiry[]> {
    const res = await fetch('/api/admin/enquiries', { headers: getAuthHeaders() });
    if (!res.ok) throw new Error('Failed to fetch enquiries');
    const data = await res.json();
    return data.enquiries;
  },

  async updateEnquiryStatus(id: string, status: 'pending' | 'resolved'): Promise<CustomerEnquiry> {
    const res = await fetch(`/api/admin/enquiries/${id}`, {
      method: 'PATCH',
      headers: getAuthHeaders(),
      body: JSON.stringify({ status })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update enquiry status');
    return data.enquiry;
  },

  async deleteEnquiry(id: string): Promise<void> {
    const res = await fetch(`/api/admin/enquiries/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders()
    });
    if (!res.ok) throw new Error('Failed to delete enquiry');
  },

  // Supabase Settings
  async getSupabaseConfig(): Promise<SupabaseConfig> {
    const res = await fetch('/api/admin/supabase-config', { headers: getAuthHeaders() });
    if (!res.ok) throw new Error('Failed to fetch Supabase config');
    const data = await res.json();
    return data.config;
  },

  async saveSupabaseConfig(project_url: string, publishable_key: string): Promise<{
    success: boolean;
    config: SupabaseConfig;
    testResult: {
      success: boolean;
      message: string;
      cleanedUrl?: string;
      cleanedKey?: string;
      tableExists?: boolean;
      tableCount?: number;
      warnings?: string[];
    };
  }> {
    const res = await fetch('/api/admin/supabase-config', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ project_url, publishable_key })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to save configuration');
    return data;
  },

  async testSupabaseConnection(project_url: string, publishable_key: string): Promise<{
    success: boolean;
    message: string;
    cleanedUrl?: string;
    cleanedKey?: string;
    tableExists?: boolean;
    tableCount?: number;
    warnings?: string[];
  }> {
    const res = await fetch('/api/admin/supabase-test', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ project_url, publishable_key })
    });
    return res.json();
  },

  async pushPropertiesToSupabase(): Promise<{ success: boolean; pushed: number; message: string }> {
    const res = await fetch('/api/admin/supabase-push', {
      method: 'POST',
      headers: getAuthHeaders()
    });
    return res.json();
  },

  async pullPropertiesFromSupabase(): Promise<{ success: boolean; pulled: number; message: string }> {
    const res = await fetch('/api/admin/supabase-pull', {
      method: 'POST',
      headers: getAuthHeaders()
    });
    return res.json();
  }
};
