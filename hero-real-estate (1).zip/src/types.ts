export type PropertyType = 
  | 'duplex' 
  | 'apartment' 
  | 'bungalow' 
  | 'terrace' 
  | 'mansion' 
  | 'penthouse' 
  | 'land' 
  | 'commercial';

export type ListingType = 'rent' | 'sale' | 'lease';

export type AvailabilityStatus = 'available' | 'rented' | 'sold' | 'unavailable';

export interface Property {
  id: string;
  title: string;
  description: string;
  property_type: PropertyType;
  listing_type: ListingType;
  price: number;
  price_period?: 'year' | 'month' | 'outright';
  state: string;
  city: string;
  address: string;
  bedrooms: number;
  bathrooms: number;
  parking_spaces: number;
  image_urls: string[];
  availability_status: AvailabilityStatus;
  published: boolean;
  featured: boolean;
  amenities: string[];
  created_at: string;
  updated_at: string;
}

export interface CustomerEnquiry {
  id: string;
  customer_name: string;
  phone_number: string;
  email: string;
  message: string;
  property_id?: string;
  property_title?: string;
  status: 'pending' | 'resolved';
  created_at: string;
}

export interface AdminAuthSession {
  token: string;
  username: string;
  role: string;
  is_initial_password: boolean;
}

export interface SupabaseConfig {
  project_url: string;
  publishable_key: string;
  status: 'unconfigured' | 'connected' | 'error';
  last_tested?: string;
  error_message?: string;
}

export interface DashboardStats {
  total_properties: number;
  properties_for_rent: number;
  properties_for_sale: number;
  total_enquiries: number;
  pending_enquiries: number;
  recently_added: Property[];
}
