export const COMPANY_PHONE = '09024971419';
export const COMPANY_PHONE_INTL = '+2349024971419';
export const COMPANY_PHONE_DISPLAY = '0902 497 1419';
export const COMPANY_WHATSAPP = '2349024971419';
export const COMPANY_WHATSAPP_DISPLAY = '09024971419';
export const COMPANY_EMAIL = 'info@herorealestate.ng';

export function formatNaira(amount: number, period?: 'year' | 'month' | 'outright'): string {
  const formatted = new Intl.NumberFormat('en-NG', {
    style: 'currency',
    currency: 'NGN',
    maximumFractionDigits: 0
  }).format(amount);

  // Replace NGN symbol with standard Nigerian Naira ₦ symbol
  const withNaira = formatted.replace('NGN', '₦').trim();

  if (period === 'year') {
    return `${withNaira}/year`;
  }
  if (period === 'month') {
    return `${withNaira}/month`;
  }
  return withNaira;
}

export function formatPriceCompact(amount: number): string {
  if (amount >= 1_000_000_000) {
    return `₦${(amount / 1_000_000_000).toFixed(1)}B`;
  }
  if (amount >= 1_000_000) {
    return `₦${(amount / 1_000_000).toFixed(1)}M`;
  }
  return `₦${amount.toLocaleString()}`;
}

export function getWhatsAppUrl(phone = COMPANY_WHATSAPP, customMessage?: string): string {
  let cleanPhone = phone.replace(/\D/g, '');
  if (cleanPhone.startsWith('0') && cleanPhone.length === 11) {
    cleanPhone = '234' + cleanPhone.slice(1);
  }
  const text = customMessage || 'Hello HERO REAL ESTATE, I would like to enquire about properties in Nigeria.';
  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(text)}`;
}

export function getPropertyWhatsAppUrl(propertyTitle: string, price: number, location: string): string {
  const message = `Hello HERO REAL ESTATE, I am interested in inspecting the following property listed on your website:\n\n*${propertyTitle}*\nLocation: ${location}\nPrice: ${formatNaira(price)}\n\nPlease provide more details on availability.`;
  return getWhatsAppUrl(COMPANY_WHATSAPP, message);
}
